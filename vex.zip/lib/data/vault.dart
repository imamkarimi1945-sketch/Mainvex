import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:exif/exif.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class ExifInfo {
  DateTime? date;
  double? lat;
  double? lng;
}

/// ذخیره‌ی فایل‌ها در پوشه‌ی خصوصی برنامه.
class Vault {
  Vault._();
  static late Directory dir;
  static late Directory cache;

  static Future<void> init() async {
    final base = await getApplicationDocumentsDirectory();
    dir = Directory(p.join(base.path, 'vex', 'files'));
    await dir.create(recursive: true);
    cache = await getTemporaryDirectory();
    await cleanTemp();
  }

  static String path(String name) => p.join(dir.path, name);

  static const _img = <String>{'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.heic', '.heif'};
  static const _vid = <String>{'.mp4', '.mkv', '.mov', '.avi', '.3gp', '.webm', '.m4v'};
  static const _aud = <String>{'.mp3', '.m4a', '.aac', '.wav', '.ogg', '.opus', '.flac', '.amr'};

  static String kindOf(String name) {
    final e = p.extension(name).toLowerCase();
    if (_img.contains(e)) return 'image';
    if (_vid.contains(e)) return 'video';
    if (_aud.contains(e)) return 'audio';
    return 'file';
  }

  static Future<String> hashOf(String srcPath) async {
    final d = await sha256.bind(File(srcPath).openRead()).first;
    return d.toString();
  }

  /// فایل را به پوشه‌ی برنامه کپی می‌کند و نام ذخیره‌شده را برمی‌گرداند.
  static Future<String> store(String srcPath, String origName) async {
    final ext = p.extension(origName).toLowerCase();
    final rnd = Random.secure().nextInt(1 << 30).toRadixString(36);
    final name = '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}$rnd$ext';
    await File(srcPath).copy(path(name));
    return name;
  }

  /// حذف کامل (بهترین تلاش: روی‌نویسی با صفر و سپس حذف)
  static Future<void> shred(String? name) async {
    if (name == null || name.isEmpty) return;
    final f = File(path(name));
    try {
      if (await f.exists()) {
        final len = await f.length();
        final raf = await f.open(mode: FileMode.write);
        final zeros = List<int>.filled(1 << 16, 0);
        var left = len;
        while (left > 0) {
          final n = min(left, zeros.length);
          await raf.writeFrom(zeros, 0, n);
          left -= n;
        }
        await raf.flush();
        await raf.close();
        await f.delete();
      }
    } catch (_) {
      try {
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  /// کپی موقت (برای باز کردن/اشتراک/گالری) با نام اصلی.
  static Future<String> tempCopy(String stored, String origName) async {
    final d = Directory(p.join(cache.path, 'vexopen', DateTime.now().microsecondsSinceEpoch.toString()));
    await d.create(recursive: true);
    final safe = origName.trim().isEmpty ? stored : origName.replaceAll(RegExp(r'[\\/]'), '_');
    final dst = p.join(d.path, safe);
    await File(path(stored)).copy(dst);
    return dst;
  }

  static Future<void> cleanTemp() async {
    try {
      final a = Directory(p.join(cache.path, 'vexopen'));
      if (await a.exists()) await a.delete(recursive: true);
      final b = Directory(p.join(cache.path, 'vex_restore'));
      if (await b.exists()) await b.delete(recursive: true);
      for (final e in cache.listSync()) {
        if (e is File && p.basename(e.path).startsWith('vex_') && e.path.endsWith('.vex')) {
          e.deleteSync();
        }
      }
    } catch (_) {}
  }

  static Future<ExifInfo> exif(String srcPath) async {
    final r = ExifInfo();
    try {
      final len = await File(srcPath).length();
      if (len > 60 * 1024 * 1024) return r;
      final tags = await readExifFromFile(File(srcPath));
      final dt = tags['EXIF DateTimeOriginal'] ?? tags['Image DateTime'];
      if (dt != null) {
        final m = RegExp(r'(\d{4}):(\d{2}):(\d{2})[ T](\d{2}):(\d{2}):(\d{2})').firstMatch(dt.printable);
        if (m != null) {
          final y = int.parse(m.group(1)!);
          if (y > 1990) {
            r.date = DateTime(y, int.parse(m.group(2)!), int.parse(m.group(3)!), int.parse(m.group(4)!),
                int.parse(m.group(5)!), int.parse(m.group(6)!));
          }
        }
      }
      double? coord(String k, String refK) {
        final t = tags[k];
        final ref = tags[refK];
        if (t == null || ref == null) return null;
        final vals = t.values.toList();
        if (vals.length < 3) return null;
        double v(dynamic x) => (x.numerator as num) / (x.denominator as num);
        var d = v(vals[0]) + v(vals[1]) / 60 + v(vals[2]) / 3600;
        final rs = ref.printable.toUpperCase();
        if (rs.startsWith('S') || rs.startsWith('W')) d = -d;
        return d;
      }

      final la = coord('GPS GPSLatitude', 'GPS GPSLatitudeRef');
      final lo = coord('GPS GPSLongitude', 'GPS GPSLongitudeRef');
      if (la != null && lo != null && la.abs() <= 90 && lo.abs() <= 180 && !(la == 0 && lo == 0)) {
        r.lat = la;
        r.lng = lo;
      }
    } catch (_) {}
    return r;
  }
}
