import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as p;

import '../core/util.dart';
import 'db.dart';
import 'vault.dart';

/// قالب فایل: VEXBK | نسخه | salt(16) | iters(4) | تکه‌های AES-256-GCM
/// هر تکه: [طول ۴ بایت (بیت بالا = تکه‌ی آخر)] [nonce(12)+cipher+mac(16)]
/// داده‌ی ساده: رکوردهای [nameLen u16][name][dataLen u64][data] و پایان با nameLen=0
class BackupException implements Exception {
  BackupException(this.message);
  final String message;
  @override
  String toString() => message;
}

const List<int> _magic = <int>[0x56, 0x45, 0x58, 0x42, 0x4B];
const int _iters = 150000;
const int _chunk = 1 << 20;
const int _headerLen = 26;
final AesGcm _algo = AesGcm.with256bits();

Future<SecretKey> _derive(String pw, List<int> salt, int iters) {
  final kdf = Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: iters, bits: 256);
  return kdf.deriveKeyFromPassword(password: pw, nonce: salt);
}

List<int> _aad(int idx, bool last) {
  final b = ByteData(9)..setUint64(0, idx);
  b.setUint8(8, last ? 1 : 0);
  return b.buffer.asUint8List();
}

Uint8List _u32(int v) => (ByteData(4)..setUint32(0, v)).buffer.asUint8List();

class _Writer {
  _Writer(this.raf, this.key);
  final RandomAccessFile raf;
  final SecretKey key;
  final BytesBuilder _buf = BytesBuilder(copy: false);
  int _idx = 0;

  Future<void> add(List<int> data) async {
    _buf.add(data);
    while (_buf.length >= _chunk) {
      final all = _buf.takeBytes();
      await _emit(Uint8List.sublistView(all, 0, _chunk), false);
      if (all.length > _chunk) _buf.add(Uint8List.sublistView(all, _chunk));
    }
  }

  Future<void> head(String name, int len) async {
    final nb = utf8.encode(name);
    final h = BytesBuilder();
    h.add((ByteData(2)..setUint16(0, nb.length)).buffer.asUint8List());
    h.add(nb);
    h.add((ByteData(8)..setUint64(0, len)).buffer.asUint8List());
    await add(h.toBytes());
  }

  Future<void> _emit(Uint8List plain, bool last) async {
    final box = await _algo.encrypt(plain, secretKey: key, aad: _aad(_idx++, last));
    final cat = box.concatenation();
    final len = cat.length | (last ? 0x80000000 : 0);
    await raf.writeFrom(_u32(len));
    await raf.writeFrom(cat);
    await Future<void>.delayed(Duration.zero);
  }

  Future<void> finish() => _emit(_buf.takeBytes(), true);
}

class _Reader {
  _Reader(this.raf, this.key);
  final RandomAccessFile raf;
  final SecretKey key;
  int _idx = 0;
  bool _done = false;
  Uint8List _cur = Uint8List(0);
  int _pos = 0;

  Future<bool> _next() async {
    if (_done) return false;
    final lb = await raf.read(4);
    if (lb.length < 4) throw BackupException('فایل بکاپ ناقص است.');
    final len0 = ByteData.sublistView(lb).getUint32(0);
    final last = (len0 & 0x80000000) != 0;
    final len = len0 & 0x7FFFFFFF;
    if (len < 28 || len > _chunk + 64) throw BackupException('فایل بکاپ آسیب دیده است.');
    final cat = await raf.read(len);
    if (cat.length < len) throw BackupException('فایل بکاپ ناقص است.');
    try {
      final box = SecretBox.fromConcatenation(cat, nonceLength: 12, macLength: 16);
      final plain = await _algo.decrypt(box, secretKey: key, aad: _aad(_idx++, last));
      _cur = Uint8List.fromList(plain);
    } catch (_) {
      throw BackupException('رمز اشتباه است یا فایل آسیب دیده است.');
    }
    _pos = 0;
    if (last) _done = true;
    await Future<void>.delayed(Duration.zero);
    return true;
  }

  Future<Uint8List> read(int n) async {
    final out = BytesBuilder(copy: false);
    var need = n;
    while (need > 0) {
      if (_pos >= _cur.length) {
        if (!await _next()) throw BackupException('فایل بکاپ ناقص است.');
        continue;
      }
      final take = min(need, _cur.length - _pos);
      out.add(Uint8List.sublistView(_cur, _pos, _pos + take));
      _pos += take;
      need -= take;
    }
    return out.takeBytes();
  }

  Future<void> verifyEnd() async {
    while (!_done) {
      if (_pos < _cur.length) throw BackupException('فایل بکاپ آسیب دیده است.');
      if (!await _next()) break;
    }
    if (_pos < _cur.length) throw BackupException('فایل بکاپ آسیب دیده است.');
  }
}

/// ساخت بکاپ رمزگذاری‌شده؛ مسیر فایل را برمی‌گرداند.
Future<String> createBackup(String password, void Function(double) onProgress) async {
  final now = DateTime.now();
  final stamp = '${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}';
  final out = File(p.join(Vault.cache.path, 'vex_$stamp.vex'));
  final raf = await out.open(mode: FileMode.write);
  try {
    final rnd = Random.secure();
    final salt = List<int>.generate(16, (_) => rnd.nextInt(256));
    final key = await _derive(password, salt, _iters);
    final hdr = BytesBuilder()
      ..add(_magic)
      ..addByte(1)
      ..add(salt)
      ..add(_u32(_iters));
    await raf.writeFrom(hdr.toBytes());
    final w = _Writer(raf, key);

    final dbBytes = utf8.encode(jsonEncode(await Db.i.exportAll()));
    await w.head('db.json', dbBytes.length);
    await w.add(dbBytes);

    final files = Vault.dir.listSync().whereType<File>().toList();
    var total = dbBytes.length;
    for (final f in files) {
      total += f.lengthSync();
    }
    var done = dbBytes.length;
    var lastReport = 0;
    for (final f in files) {
      final len = await f.length();
      await w.head('f/${p.basename(f.path)}', len);
      var written = 0;
      await for (final c in f.openRead()) {
        if (written + c.length > len) {
          await w.add(c.sublist(0, len - written));
          written = len;
          break;
        }
        await w.add(c);
        written += c.length;
        done += c.length;
        if (done - lastReport > 512 * 1024) {
          lastReport = done;
          onProgress(total == 0 ? 1 : min(1.0, done / total));
        }
      }
      if (written < len) {
        await w.add(Uint8List(len - written));
      }
    }
    await w.head('', 0);
    await w.finish();
    onProgress(1);
  } catch (e) {
    await raf.close();
    try {
      await out.delete();
    } catch (_) {}
    rethrow;
  }
  await raf.close();
  return out.path;
}

/// بازیابی کامل؛ اطلاعات فعلی جایگزین می‌شود.
Future<void> restoreBackup(String path, String password, void Function(double) onProgress) async {
  final f = File(path);
  final raf = await f.open();
  final tmp = Directory(p.join(Vault.cache.path, 'vex_restore'));
  try {
    if (await tmp.exists()) await tmp.delete(recursive: true);
    await tmp.create(recursive: true);

    final h = await raf.read(_headerLen);
    var okMagic = h.length == _headerLen;
    if (okMagic) {
      for (var i = 0; i < _magic.length; i++) {
        if (h[i] != _magic[i]) okMagic = false;
      }
    }
    if (!okMagic) throw BackupException('این فایل، بکاپ Vex نیست.');
    final salt = h.sublist(6, 22);
    final iters = ByteData.sublistView(h).getUint32(22);
    if (iters < 10000 || iters > 5000000) throw BackupException('فایل بکاپ آسیب دیده است.');
    final key = await _derive(password, salt, iters);
    final r = _Reader(raf, key);
    final total = max(1, await f.length());

    Map<String, dynamic>? data;
    while (true) {
      final nl = ByteData.sublistView(await r.read(2)).getUint16(0);
      if (nl == 0) {
        await r.read(8);
        break;
      }
      final name = utf8.decode(await r.read(nl));
      final len = ByteData.sublistView(await r.read(8)).getUint64(0);
      if (name == 'db.json') {
        data = jsonDecode(utf8.decode(await r.read(len))) as Map<String, dynamic>;
      } else if (name.startsWith('f/')) {
        final fname = p.basename(name.substring(2));
        final sink = File(p.join(tmp.path, fname)).openWrite();
        var left = len;
        while (left > 0) {
          final n = min(left, _chunk);
          sink.add(await r.read(n));
          left -= n;
        }
        await sink.close();
      } else {
        var left = len;
        while (left > 0) {
          final n = min(left, _chunk);
          await r.read(n);
          left -= n;
        }
      }
      onProgress(min(1.0, (await raf.position()) / total));
    }
    await r.verifyEnd();
    if (data == null) throw BackupException('داده‌ی بکاپ پیدا نشد.');

    await Db.i.replaceAll(data);
    for (final e in Vault.dir.listSync()) {
      try {
        e.deleteSync(recursive: true);
      } catch (_) {}
    }
    for (final e in tmp.listSync()) {
      if (e is File) {
        final dst = Vault.path(p.basename(e.path));
        try {
          e.renameSync(dst);
        } catch (_) {
          e.copySync(dst);
          e.deleteSync();
        }
      }
    }
    onProgress(1);
  } finally {
    await raf.close();
    try {
      if (await tmp.exists()) await tmp.delete(recursive: true);
    } catch (_) {}
  }
}
