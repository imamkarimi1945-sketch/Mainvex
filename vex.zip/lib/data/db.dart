import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'vault.dart';

int _now() => DateTime.now().millisecondsSinceEpoch;

class Person {
  Person({
    this.id = 0,
    required this.name,
    this.alias = '',
    this.notes = '',
    this.photo,
    this.conf = 0,
    int? created,
    int? updated,
    this.deletedAt,
  })  : created = created ?? _now(),
        updated = updated ?? _now();

  int id;
  String name;
  String alias;
  String notes;
  String? photo;
  int conf;
  int created;
  int updated;
  int? deletedAt;

  String get code => 'P-${id.toString().padLeft(4, '0')}';

  Map<String, Object?> toMap() => <String, Object?>{
        'id': id,
        'name': name,
        'alias': alias,
        'notes': notes,
        'photo': photo,
        'conf': conf,
        'created': created,
        'updated': updated,
        'deleted_at': deletedAt,
      };

  factory Person.fromMap(Map<String, Object?> m) => Person(
        id: m['id'] as int,
        name: (m['name'] as String?) ?? '',
        alias: (m['alias'] as String?) ?? '',
        notes: (m['notes'] as String?) ?? '',
        photo: m['photo'] as String?,
        conf: (m['conf'] as int?) ?? 0,
        created: (m['created'] as int?) ?? 0,
        updated: (m['updated'] as int?) ?? 0,
        deletedAt: m['deleted_at'] as int?,
      );
}

class Item {
  Item({
    this.id = 0,
    required this.title,
    required this.kind,
    this.file,
    this.origName = '',
    this.size = 0,
    this.hash = '',
    this.body = '',
    this.subject = '',
    this.tags = '',
    this.details = '',
    this.conf = 0,
    this.rel = 'D',
    int? date,
    this.lat,
    this.lng,
    int? created,
    this.deletedAt,
    List<int>? personIds,
  })  : date = date ?? _now(),
        created = created ?? _now(),
        personIds = personIds ?? <int>[];

  int id;
  String title;
  String kind; // image | video | audio | file | note | location
  String? file;
  String origName;
  int size;
  String hash;
  String body;
  String subject;
  String tags; // "#a #b"
  String details;
  int conf;
  String rel;
  int date;
  double? lat;
  double? lng;
  int created;
  int? deletedAt;
  List<int> personIds;

  String get code => 'F-${id.toString().padLeft(5, '0')}';
  DateTime get dateTime => DateTime.fromMillisecondsSinceEpoch(date);
  List<String> get tagList => tags.split(' ').where((e) => e.isNotEmpty).toList();
  bool get hasFile => file != null && file!.isNotEmpty;

  Map<String, Object?> toMap() => <String, Object?>{
        'id': id,
        'title': title,
        'kind': kind,
        'file': file,
        'orig_name': origName,
        'size': size,
        'hash': hash,
        'body': body,
        'subject': subject,
        'tags': tags,
        'details': details,
        'conf': conf,
        'rel': rel,
        'date': date,
        'lat': lat,
        'lng': lng,
        'created': created,
        'deleted_at': deletedAt,
      };

  factory Item.fromMap(Map<String, Object?> m, List<int> pids) => Item(
        id: m['id'] as int,
        title: (m['title'] as String?) ?? '',
        kind: (m['kind'] as String?) ?? 'file',
        file: m['file'] as String?,
        origName: (m['orig_name'] as String?) ?? '',
        size: (m['size'] as int?) ?? 0,
        hash: (m['hash'] as String?) ?? '',
        body: (m['body'] as String?) ?? '',
        subject: (m['subject'] as String?) ?? '',
        tags: (m['tags'] as String?) ?? '',
        details: (m['details'] as String?) ?? '',
        conf: (m['conf'] as int?) ?? 0,
        rel: (m['rel'] as String?) ?? 'D',
        date: (m['date'] as int?) ?? 0,
        lat: (m['lat'] as num?)?.toDouble(),
        lng: (m['lng'] as num?)?.toDouble(),
        created: (m['created'] as int?) ?? 0,
        deletedAt: m['deleted_at'] as int?,
        personIds: List<int>.of(pids),
      );
}

class Place {
  Place({
    this.id = 0,
    required this.personId,
    required this.title,
    this.address = '',
    required this.lat,
    required this.lng,
    this.notes = '',
    int? created,
  }) : created = created ?? _now();

  int id;
  int personId;
  String title;
  String address;
  double lat;
  double lng;
  String notes;
  int created;

  Map<String, Object?> toMap() => <String, Object?>{
        'id': id,
        'person_id': personId,
        'title': title,
        'address': address,
        'lat': lat,
        'lng': lng,
        'notes': notes,
        'created': created,
      };

  factory Place.fromMap(Map<String, Object?> m) => Place(
        id: m['id'] as int,
        personId: m['person_id'] as int,
        title: (m['title'] as String?) ?? '',
        address: (m['address'] as String?) ?? '',
        lat: (m['lat'] as num).toDouble(),
        lng: (m['lng'] as num).toDouble(),
        notes: (m['notes'] as String?) ?? '',
        created: (m['created'] as int?) ?? 0,
      );
}

class RoutePath {
  RoutePath({
    this.id = 0,
    required this.type,
    required this.name,
    required this.points,
    this.notes = '',
    int? date,
    int? created,
  })  : date = date ?? _now(),
        created = created ?? _now();

  int id;
  String type; // مثلا: موتور، ماشین، پهباد، گله — آزاد و قابل‌افزودن
  String name; // مثلا: موتور ۲، پهباد اصلی
  List<List<double>> points; // [[lat,lng], ...]
  String notes;
  int date;
  int created;

  String get code => 'R-${id.toString().padLeft(4, '0')}';
  DateTime get dateTime => DateTime.fromMillisecondsSinceEpoch(date);

  Map<String, Object?> toMap() => <String, Object?>{
        'id': id,
        'type': type,
        'name': name,
        'points': jsonEncode(points),
        'notes': notes,
        'date': date,
        'created': created,
      };

  factory RoutePath.fromMap(Map<String, Object?> m) {
    final raw = (m['points'] as String?) ?? '[]';
    List<List<double>> pts;
    try {
      pts = (jsonDecode(raw) as List)
          .map((e) => (e as List).map((v) => (v as num).toDouble()).toList())
          .toList();
    } catch (_) {
      pts = <List<double>>[];
    }
    return RoutePath(
      id: m['id'] as int,
      type: (m['type'] as String?) ?? '',
      name: (m['name'] as String?) ?? '',
      points: pts,
      notes: (m['notes'] as String?) ?? '',
      date: (m['date'] as int?) ?? 0,
      created: (m['created'] as int?) ?? 0,
    );
  }
}

/// عکسِ لحظه‌ای از همه‌ی داده‌ها (برای صفحه‌ها)
class Snap {
  Snap(this.persons, this.items, this.places)
      : pmap = <int, Person>{for (final x in persons) x.id: x};
  final List<Person> persons;
  final List<Item> items;
  final List<Place> places;
  final Map<int, Person> pmap;

  String namesOf(Item it) =>
      it.personIds.map((e) => pmap[e]?.name).whereType<String>().join('، ');

  List<Item> itemsOf(int personId) => items.where((e) => e.personIds.contains(personId)).toList();
}

class Db {
  Db._();
  static final Db i = Db._();

  late Database _db;
  final ValueNotifier<int> tick = ValueNotifier<int>(0);
  void _bump() => tick.value++;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'vex.db');
    _db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE persons(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, '
          'alias TEXT, notes TEXT, photo TEXT, conf INTEGER DEFAULT 0, created INTEGER, updated INTEGER, deleted_at INTEGER)');
      await d.execute('CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, kind TEXT, file TEXT, '
          'orig_name TEXT, size INTEGER, hash TEXT, body TEXT, subject TEXT, tags TEXT, details TEXT, '
          'conf INTEGER DEFAULT 0, rel TEXT, date INTEGER, lat REAL, lng REAL, created INTEGER, deleted_at INTEGER)');
      await d.execute('CREATE TABLE item_persons(item_id INTEGER, person_id INTEGER, PRIMARY KEY(item_id, person_id))');
      await d.execute('CREATE TABLE places(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER, title TEXT, '
          'address TEXT, lat REAL, lng REAL, notes TEXT, created INTEGER)');
      await d.execute('CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT)');
      await d.execute('CREATE TABLE routes(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, name TEXT, '
          'points TEXT, notes TEXT, date INTEGER, created INTEGER)');
    });
    await purgeTrashOlderThan(const Duration(days: 30));
  }

  // ───────── kv ─────────
  Future<String?> kvGet(String k) async {
    final r = await _db.query('kv', where: 'k=?', whereArgs: <Object?>[k]);
    return r.isEmpty ? null : r.first['v'] as String?;
  }

  Future<void> kvSet(String k, String v) async {
    await _db.insert('kv', <String, Object?>{'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ───────── persons ─────────
  Future<List<Person>> persons({bool trashed = false}) async {
    final rows = await _db.query('persons',
        where: trashed ? 'deleted_at IS NOT NULL' : 'deleted_at IS NULL', orderBy: 'name COLLATE NOCASE');
    return rows.map(Person.fromMap).toList();
  }

  Future<int> savePerson(Person x) async {
    x.updated = _now();
    if (x.id == 0) {
      final m = x.toMap()..remove('id');
      x.id = await _db.insert('persons', m);
    } else {
      await _db.update('persons', x.toMap(), where: 'id=?', whereArgs: <Object?>[x.id]);
    }
    _bump();
    return x.id;
  }

  Future<void> trashPerson(int id) async {
    await _db.update('persons', <String, Object?>{'deleted_at': _now()}, where: 'id=?', whereArgs: <Object?>[id]);
    _bump();
  }

  Future<void> restorePerson(int id) async {
    await _db.update('persons', <String, Object?>{'deleted_at': null}, where: 'id=?', whereArgs: <Object?>[id]);
    _bump();
  }

  Future<void> purgePerson(int id) async {
    final r = await _db.query('persons', where: 'id=?', whereArgs: <Object?>[id]);
    final photo = r.isEmpty ? null : r.first['photo'] as String?;
    await _db.delete('persons', where: 'id=?', whereArgs: <Object?>[id]);
    await _db.delete('item_persons', where: 'person_id=?', whereArgs: <Object?>[id]);
    await _db.delete('places', where: 'person_id=?', whereArgs: <Object?>[id]);
    await Vault.shred(photo);
    _bump();
  }

  // ───────── items ─────────
  Future<List<Item>> items({bool trashed = false}) async {
    final rows = await _db.query('items',
        where: trashed ? 'deleted_at IS NOT NULL' : 'deleted_at IS NULL', orderBy: 'date DESC, id DESC');
    final links = await _db.query('item_persons');
    final by = <int, List<int>>{};
    for (final l in links) {
      by.putIfAbsent(l['item_id'] as int, () => <int>[]).add(l['person_id'] as int);
    }
    return rows.map((r) => Item.fromMap(r, by[r['id'] as int] ?? <int>[])).toList();
  }

  Future<Item?> itemByHash(String hash) async {
    final r = await _db.query('items', where: 'hash=? AND deleted_at IS NULL', whereArgs: <Object?>[hash], limit: 1);
    if (r.isEmpty) return null;
    return Item.fromMap(r.first, <int>[]);
  }

  Future<int> saveItem(Item it) async {
    final m = it.toMap();
    await _db.transaction((txn) async {
      if (it.id == 0) {
        m.remove('id');
        it.id = await txn.insert('items', m);
      } else {
        await txn.update('items', m, where: 'id=?', whereArgs: <Object?>[it.id]);
      }
      await txn.delete('item_persons', where: 'item_id=?', whereArgs: <Object?>[it.id]);
      for (final pid in it.personIds) {
        await txn.insert('item_persons', <String, Object?>{'item_id': it.id, 'person_id': pid},
            conflictAlgorithm: ConflictAlgorithm.ignore);
      }
    });
    _bump();
    return it.id;
  }

  Future<void> trashItem(int id) async {
    await _db.update('items', <String, Object?>{'deleted_at': _now()}, where: 'id=?', whereArgs: <Object?>[id]);
    _bump();
  }

  Future<void> restoreItem(int id) async {
    await _db.update('items', <String, Object?>{'deleted_at': null}, where: 'id=?', whereArgs: <Object?>[id]);
    _bump();
  }

  Future<void> purgeItem(int id) async {
    final r = await _db.query('items', where: 'id=?', whereArgs: <Object?>[id]);
    final file = r.isEmpty ? null : r.first['file'] as String?;
    await _db.delete('items', where: 'id=?', whereArgs: <Object?>[id]);
    await _db.delete('item_persons', where: 'item_id=?', whereArgs: <Object?>[id]);
    await Vault.shred(file);
    _bump();
  }

  // ───────── places ─────────
  Future<List<Place>> places() async {
    final rows = await _db.query('places', orderBy: 'id DESC');
    return rows.map(Place.fromMap).toList();
  }

  Future<void> savePlace(Place x) async {
    if (x.id == 0) {
      final m = x.toMap()..remove('id');
      x.id = await _db.insert('places', m);
    } else {
      await _db.update('places', x.toMap(), where: 'id=?', whereArgs: <Object?>[x.id]);
    }
    _bump();
  }

  Future<void> deletePlace(int id) async {
    await _db.delete('places', where: 'id=?', whereArgs: <Object?>[id]);
    _bump();
  }

  // ───────── مسیرها ─────────
  Future<List<RoutePath>> routes() async {
    final rows = await _db.query('routes', orderBy: 'date DESC, id DESC');
    return rows.map(RoutePath.fromMap).toList();
  }

  /// نوع‌هایی که قبلاً استفاده شده‌اند (برای پیشنهاد در دیالوگ ثبت)
  Future<List<String>> routeTypes() async {
    final rows = await _db.query('routes', columns: <String>['type'], distinct: true, orderBy: 'type');
    return rows.map((r) => (r['type'] as String?) ?? '').where((e) => e.isNotEmpty).toList();
  }

  Future<int> saveRoute(RoutePath x) async {
    if (x.id == 0) {
      final m = x.toMap()..remove('id');
      x.id = await _db.insert('routes', m);
    } else {
      await _db.update('routes', x.toMap(), where: 'id=?', whereArgs: <Object?>[x.id]);
    }
    _bump();
    return x.id;
  }

  Future<void> deleteRoute(int id) async {
    await _db.delete('routes', where: 'id=?', whereArgs: <Object?>[id]);
    _bump();
  }

  // ───────── ترکیبی ─────────
  Future<Snap> all() async {
    final ps = await persons();
    final its = await items();
    final pl = await places();
    final alive = ps.map((e) => e.id).toSet();
    return Snap(ps, its, pl.where((e) => alive.contains(e.personId)).toList());
  }

  Future<void> purgeTrashOlderThan(Duration d) async {
    final limit = _now() - d.inMilliseconds;
    final its = await _db.query('items', columns: <String>['id'], where: 'deleted_at IS NOT NULL AND deleted_at < ?', whereArgs: <Object?>[limit]);
    for (final r in its) {
      await purgeItem(r['id'] as int);
    }
    final ps = await _db.query('persons', columns: <String>['id'], where: 'deleted_at IS NOT NULL AND deleted_at < ?', whereArgs: <Object?>[limit]);
    for (final r in ps) {
      await purgePerson(r['id'] as int);
    }
  }

  Future<void> emptyTrash() async {
    final its = await _db.query('items', columns: <String>['id'], where: 'deleted_at IS NOT NULL');
    for (final r in its) {
      await purgeItem(r['id'] as int);
    }
    final ps = await _db.query('persons', columns: <String>['id'], where: 'deleted_at IS NOT NULL');
    for (final r in ps) {
      await purgePerson(r['id'] as int);
    }
  }

  // ───────── بکاپ ─────────
  Future<Map<String, Object?>> exportAll() async => <String, Object?>{
        'v': 1,
        'persons': await _db.query('persons'),
        'items': await _db.query('items'),
        'links': await _db.query('item_persons'),
        'places': await _db.query('places'),
        'routes': await _db.query('routes'),
      };

  Future<void> replaceAll(Map<String, dynamic> data) async {
    await _db.transaction((txn) async {
      for (final t in <String>['item_persons', 'places', 'routes', 'items', 'persons']) {
        await txn.delete(t);
      }
      Future<void> put(String table, String key) async {
        final list = (data[key] as List?) ?? const <dynamic>[];
        for (final r in list) {
          await txn.insert(table, Map<String, Object?>.from(r as Map));
        }
      }

      await put('persons', 'persons');
      await put('items', 'items');
      await put('item_persons', 'links');
      await put('places', 'places');
      await put('routes', 'routes');
    });
    _bump();
  }
}
