import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme.dart';
import 'data/db.dart';
import 'data/security.dart';
import 'data/vault.dart';
import 'ui/lock.dart';
import 'ui/splash.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Vault.init();
  await Db.i.init();
  await Security.i.load();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: V.bg2,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const VexApp());
}

class VexApp extends StatelessWidget {
  const VexApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Vex',
        debugShowCheckedModeBanner: false,
        theme: vexTheme(),
        locale: const Locale('fa', 'IR'),
        supportedLocales: const <Locale>[Locale('fa', 'IR'), Locale('en', 'US')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        builder: (context, child) => AppGuard(child: child ?? const SizedBox()),
        home: const SplashPage(),
      );
}

/// قفل خودکار + پوشش قفل روی همه‌ی صفحه‌ها
class AppGuard extends StatefulWidget {
  const AppGuard({super.key, required this.child});
  final Widget child;
  @override
  State<AppGuard> createState() => _AppGuardState();
}

class _AppGuardState extends State<AppGuard> with WidgetsBindingObserver {
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Security.i.addListener(_r);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    Security.i.removeListener(_r);
    super.dispose();
  }

  void _r() {
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final s = Security.i;
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
      s.setReveal(false);
    } else if (state == AppLifecycleState.resumed) {
      final p = _pausedAt;
      _pausedAt = null;
      if (p != null && s.mode != 'off' && !s.locked) {
        if (DateTime.now().difference(p).inSeconds >= s.autoLockSec) {
          Vault.cleanTemp();
          s.lock();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Security.i;
    return Stack(children: [
      widget.child,
      if (s.locked && s.started) const Positioned.fill(child: LockScreen()),
    ]);
  }
}
