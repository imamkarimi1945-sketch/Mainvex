import 'package:flutter/material.dart';

import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/db.dart';
import '../../data/security.dart';
import '../widgets.dart';
import 'item_pages.dart';
import 'person_pages.dart';

/// جستجوی فرمانی: یک عبارت → همه‌ی اشخاص، پرونده‌ها و مکان‌های مرتبط
class SearchPage extends StatefulWidget {
  const SearchPage({super.key, this.initial, this.standalone = false});
  final String? initial;
  final bool standalone;
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _q = TextEditingController();
  int? _conf; // فیلتر سطح

  @override
  void initState() {
    super.initState();
    if (widget.initial != null) _q.text = widget.initial!;
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  bool _match(String hay, List<String> toks) {
    final h = normFa(hay);
    for (final t in toks) {
      if (!h.contains(t)) return false;
    }
    return true;
  }

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: Column(children: [
          Row(children: [
            if (widget.standalone) BackButton(onPressed: () => Navigator.pop(context)),
            Image.asset('assets/logo/vex_logo.png', width: 38, height: 38),
            const SizedBox(width: 8),
            Text('VEX', style: V.mono(size: 15, color: V.silver, spacing: 5)),
            const Spacer(),
            ListenableBuilder(
              listenable: Security.i,
              builder: (c, _) => IconButton(
                tooltip: 'نمایش/پنهان‌کردن همه‌ی فایل‌ها',
                icon: Icon(Security.i.revealAll ? Icons.visibility : Icons.visibility_off_outlined, color: Security.i.revealAll ? V.warn : V.silverDim),
                onPressed: () => Security.i.setReveal(!Security.i.revealAll),
              ),
            ),
          ]),
          const SizedBox(height: 10),
          Container(
            decoration: ShapeDecoration(
              color: V.card,
              shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: V.accent)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(children: [
              Text('>', style: V.mono(size: 16, color: V.cyan)),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _q,
                  onChanged: (_) => setState(() {}),
                  style: const TextStyle(color: V.text, fontSize: 16),
                  decoration: const InputDecoration(
                    hintText: 'شخص، موضوع، هشتگ یا هر چیزی…',
                    hintStyle: TextStyle(color: V.textDim),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              if (_q.text.isNotEmpty)
                IconButton(
                  icon: const Icon(Icons.close, color: V.silverDim, size: 20),
                  onPressed: () => setState(() => _q.clear()),
                ),
            ]),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 34,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              _chip('همه', _conf == null, V.cyan, () => setState(() => _conf = null)),
              for (var i = 0; i < 4; i++) _chip(V.confNames[i], _conf == i, V.confColors[i], () => setState(() => _conf = i)),
            ]),
          ),
        ]),
      );

  Widget _chip(String t, bool on, Color c, VoidCallback f) => Padding(
        padding: const EdgeInsetsDirectional.only(end: 8),
        child: InkWell(
          onTap: f,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            alignment: Alignment.center,
            decoration: BoxDecoration(color: on ? V.a(c, .18) : V.card, border: Border.all(color: on ? c : V.stroke)),
            child: Text(t, style: TextStyle(color: on ? c : V.textDim, fontSize: 12, fontWeight: FontWeight.w600)),
          ),
        ),
      );

  Widget _stat(String hud, String v, IconData ic) => Expanded(
        child: VexCard(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(ic, color: V.cyan, size: 20),
            const SizedBox(height: 8),
            Text(v, style: const TextStyle(color: V.text, fontSize: 22, fontWeight: FontWeight.w800)),
            Hud(hud),
          ]),
        ),
      );

  Widget _dashboard(Snap s) {
    final tags = <String, int>{};
    final subs = <String, int>{};
    for (final it in s.items) {
      for (final t in it.tagList) {
        tags[t] = (tags[t] ?? 0) + 1;
      }
      if (it.subject.isNotEmpty) subs[it.subject] = (subs[it.subject] ?? 0) + 1;
    }
    List<String> top(Map<String, int> m) {
      final k = m.keys.toList()..sort((a, b) => m[b]!.compareTo(m[a]!));
      return k.take(12).toList();
    }

    void go(String t) => setState(() => _q.text = t);
    final recent = s.items.take(8).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 30), children: [
      Row(children: [
        _stat('PERSONS', faDigits(s.persons.length), Icons.groups_outlined),
        const SizedBox(width: 10),
        _stat('FILES', faDigits(s.items.length), Icons.folder_outlined),
        const SizedBox(width: 10),
        _stat('PLACES', faDigits(s.places.length), Icons.place_outlined),
      ]),
      if (tags.isNotEmpty) ...[
        const SectionTitle('هشتگ‌های پرتکرار', hud: 'TAGS'),
        Wrap(spacing: 8, runSpacing: 8, children: [for (final t in top(tags)) TagChip(t, onTap: () => go(t))]),
      ],
      if (subs.isNotEmpty) ...[
        const SectionTitle('موضوع‌ها', hud: 'SUBJECTS'),
        Wrap(spacing: 8, runSpacing: 8, children: [for (final t in top(subs)) TagChip(t, onTap: () => go(t))]),
      ],
      const SectionTitle('آخرین ثبت‌ها', hud: 'RECENT'),
      if (recent.isEmpty)
        const Padding(padding: EdgeInsets.only(top: 30), child: EmptyState(icon: Icons.inventory_2_outlined, text: 'آرشیو خالی است.\nبا دکمه‌ی + شخص یا فایل اضافه کنید.'))
      else
        for (final it in recent) Padding(padding: const EdgeInsets.only(bottom: 10), child: ItemTile(item: it, snap: s, showSave: true)),
    ]);
  }

  Widget _results(Snap s, List<String> toks) {
    final persons = s.persons.where((e) => _match('${e.name} ${e.alias} ${e.notes} ${e.code}', toks)).toList();
    final items = s.items.where((e) {
      if (_conf != null && e.conf != _conf) return false;
      return _match('${e.title} ${e.subject} ${e.tags} ${e.details} ${e.body} ${e.origName} ${e.code} ${s.namesOf(e)}', toks);
    }).toList();
    final places = s.places.where((e) => _match('${e.title} ${e.address} ${e.notes} ${s.pmap[e.personId]?.name ?? ''}', toks)).toList();
    if (persons.isEmpty && items.isEmpty && places.isEmpty) {
      return const EmptyState(icon: Icons.search_off, text: 'چیزی پیدا نشد.');
    }
    return ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 30), children: [
      if (persons.isNotEmpty) ...[
        SectionTitle('اشخاص', hud: '${persons.length}'),
        for (final x in persons)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: VexCard(
              onTap: () => openPerson(context, x.id),
              child: Row(children: [
                PersonAvatar(person: x, size: 46),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(x.name, style: const TextStyle(color: V.text, fontWeight: FontWeight.w700)),
                    if (x.alias.isNotEmpty) Text(x.alias, style: const TextStyle(color: V.textDim, fontSize: 12)),
                  ]),
                ),
                ConfChip(x.conf, small: true),
              ]),
            ),
          ),
      ],
      if (items.isNotEmpty) ...[
        SectionTitle('پرونده‌ها', hud: '${items.length}'),
        for (final it in items) Padding(padding: const EdgeInsets.only(bottom: 10), child: ItemTile(item: it, snap: s, showSave: true)),
      ],
      if (places.isNotEmpty) ...[
        SectionTitle('مکان‌ها', hud: '${places.length}'),
        for (final pl in places)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: VexCard(
              onTap: () => openMap(context, pl.lat, pl.lng, pl.title),
              child: Row(children: [
                const Icon(Icons.place_outlined, color: V.cyan),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${pl.title} · ${s.pmap[pl.personId]?.name ?? ''}', style: const TextStyle(color: V.text)),
                    if (pl.address.isNotEmpty) Text(pl.address, style: const TextStyle(color: V.textDim, fontSize: 12)),
                  ]),
                ),
                const Icon(Icons.map_outlined, color: V.silverDim, size: 20),
              ]),
            ),
          ),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final toks = normFa(_q.text.trim()).split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
    final body = DbBuilder<Snap>(
      load: Db.i.all,
      builder: (c, s) => toks.isEmpty && _conf == null ? _dashboard(s) : _results(s, toks),
    );
    final col = Column(children: [_header(), Expanded(child: body)]);
    return widget.standalone ? Scaffold(body: SafeArea(child: col)) : SafeArea(child: col);
  }
}

// ───────────────────────── تب پرونده‌ها ─────────────────────────

class FilesPage extends StatefulWidget {
  const FilesPage({super.key});
  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  String? _kind;
  int? _conf;
  bool _oldFirst = false;

  @override
  Widget build(BuildContext context) => SafeArea(
        child: DbBuilder<Snap>(
          load: Db.i.all,
          builder: (c, s) {
            var l = s.items.where((e) => (_kind == null || e.kind == _kind) && (_conf == null || e.conf == _conf)).toList();
            if (_oldFirst) l = l.reversed.toList();
            Widget chip(String t, bool on, VoidCallback f, [Color col = V.cyan]) => Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: InkWell(
                    onTap: f,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: on ? V.a(col, .18) : V.card, border: Border.all(color: on ? col : V.stroke)),
                      child: Text(t, style: TextStyle(color: on ? col : V.textDim, fontSize: 12)),
                    ),
                  ),
                );
            return Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 8, 0),
                child: Row(children: [
                  const Hud('FILES'),
                  const SizedBox(width: 10),
                  Text('${faDigits(l.length)} مورد', style: const TextStyle(color: V.textDim, fontSize: 12)),
                  const Spacer(),
                  IconButton(
                    tooltip: 'مرتب‌سازی',
                    icon: Icon(_oldFirst ? Icons.arrow_upward : Icons.arrow_downward, color: V.silverDim, size: 20),
                    onPressed: () => setState(() => _oldFirst = !_oldFirst),
                  ),
                ]),
              ),
              SizedBox(
                height: 34,
                child: ListView(padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal, children: [
                  chip('همه', _kind == null, () => setState(() => _kind = null)),
                  for (final k in <String>['image', 'video', 'audio', 'file', 'note', 'location']) chip(kindName(k), _kind == k, () => setState(() => _kind = k)),
                ]),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 34,
                child: ListView(padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal, children: [
                  chip('هر سطح', _conf == null, () => setState(() => _conf = null)),
                  for (var i = 0; i < 4; i++) chip(V.confNames[i], _conf == i, () => setState(() => _conf = i), V.confColors[i]),
                ]),
              ),
              const SizedBox(height: 6),
              Expanded(
                child: l.isEmpty
                    ? const EmptyState(icon: Icons.folder_open, text: 'موردی برای نمایش نیست.')
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        itemCount: l.length,
                        itemBuilder: (c, i) => Padding(padding: const EdgeInsets.only(bottom: 10), child: ItemTile(item: l[i], snap: s, showSave: true)),
                      ),
              ),
            ]);
          },
        ),
      );
}
