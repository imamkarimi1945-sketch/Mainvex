import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;

import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/db.dart';
import '../../data/vault.dart';
import '../widgets.dart';
import 'person_pages.dart';
import 'search_page.dart';

void openItem(BuildContext context, int id) {
  Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ItemPage(id: id)));
}

// ───────────────────────── کاشی فایل ─────────────────────────

class ItemTile extends StatelessWidget {
  const ItemTile({super.key, required this.item, required this.snap, this.showSave = false});
  final Item item;
  final Snap snap;
  final bool showSave;

  Widget _thumb() {
    Widget inner;
    if (item.kind == 'image' && item.hasFile) {
      inner = HiddenMedia(
        hint: false,
        sigma: 12,
        child: Image.file(
          File(Vault.path(item.file!)),
          fit: BoxFit.cover,
          cacheWidth: 200,
          errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined, color: V.silverDim),
        ),
      );
    } else {
      inner = Icon(kindIcon(item.kind), color: V.cyan, size: 26);
    }
    return ClipPath(
      clipper: ShapeBorderClipper(shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(10))),
      child: Container(width: 58, height: 58, color: V.cardHi, alignment: Alignment.center, child: inner),
    );
  }

  @override
  Widget build(BuildContext context) {
    final names = snap.namesOf(item);
    final sub = <String>[if (names.isNotEmpty) names, if (item.subject.isNotEmpty) item.subject].join(' · ');
    return VexCard(
      padding: EdgeInsets.zero,
      onTap: () => openItem(context, item.id),
      child: IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(width: 4, color: V.confColors[item.conf.clamp(0, 3)]),
          Padding(padding: const EdgeInsets.all(10), child: _thumb()),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(item.title.isEmpty ? item.origName : item.title,
                    maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.text, fontWeight: FontWeight.w600)),
                if (sub.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.textDim, fontSize: 12)),
                  ),
                const SizedBox(height: 6),
                Row(children: [
                  Icon(kindIcon(item.kind), size: 13, color: V.silverDim),
                  const SizedBox(width: 4),
                  Text(jalaliShort(item.dateTime), style: const TextStyle(color: V.silverDim, fontSize: 11)),
                  const SizedBox(width: 8),
                  ConfChip(item.conf, small: true),
                ]),
              ]),
            ),
          ),
          if (showSave && (item.kind == 'image' || item.kind == 'video'))
            IconButton(
              tooltip: 'ذخیره در گالری',
              icon: const Icon(Icons.download_rounded, color: V.cyan),
              onPressed: () => saveToGallery(context, item),
            )
          else
            const SizedBox(width: 8),
        ]),
      ),
    );
  }
}

// ───────────────────────── نمایش فایل ─────────────────────────

class ItemPage extends StatelessWidget {
  const ItemPage({super.key, required this.id});
  final int id;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: DbBuilder<Snap>(
          load: Db.i.all,
          builder: (c, s) {
            Item? it;
            for (final e in s.items) {
              if (e.id == id) it = e;
            }
            if (it == null) {
              return SafeArea(child: Column(children: [
                Align(alignment: AlignmentDirectional.centerStart, child: BackButton(onPressed: () => Navigator.pop(context))),
                const Expanded(child: EmptyState(icon: Icons.folder_off_outlined, text: 'این مورد دیگر وجود ندارد.')),
              ]));
            }
            return _ItemView(item: it, snap: s);
          },
        ),
      );
}

class _ItemView extends StatelessWidget {
  const _ItemView({required this.item, required this.snap});
  final Item item;
  final Snap snap;

  Widget _media(BuildContext context) {
    final it = item;
    if (it.kind == 'image' && it.hasFile) {
      return GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => FullImagePage(item: it))),
        child: Bracket(
          pad: 6,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 360),
            child: HiddenMedia(
              child: SizedBox(
                width: double.infinity,
                height: 300,
                child: Image.file(File(Vault.path(it.file!)),
                    fit: BoxFit.cover,
                    cacheWidth: 1200,
                    errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined, color: V.silverDim))),
              ),
            ),
          ),
        ),
      );
    }
    if (it.kind == 'note') {
      return VexCard(
        child: HiddenMedia(
          sigma: 7,
          child: SizedBox(
            width: double.infinity,
            child: SelectableText(it.body, style: const TextStyle(color: V.text, height: 1.9, fontSize: 15)),
          ),
        ),
      );
    }
    if (it.kind == 'location' && it.lat != null) {
      return VexCard(
        child: Column(children: [
          const Icon(Icons.place_outlined, size: 40, color: V.cyan),
          const SizedBox(height: 8),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text('${it.lat!.toStringAsFixed(6)}, ${it.lng!.toStringAsFixed(6)}', style: V.mono(size: 13, color: V.silver)),
          ),
        ]),
      );
    }
    return VexCard(
      child: Row(children: [
        Icon(kindIcon(it.kind), size: 38, color: V.cyan),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(it.origName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.text)),
            const SizedBox(height: 4),
            Text('${kindName(it.kind)} · ${fmtSize(it.size)}', style: const TextStyle(color: V.textDim, fontSize: 12)),
          ]),
        ),
      ]),
    );
  }

  Widget _row(String k, Widget v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 78, child: Text(k, style: const TextStyle(color: V.textDim, fontSize: 12))),
          Expanded(child: v),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final it = item;
    final persons = it.personIds.map((e) => snap.pmap[e]).whereType<Person>().toList();
    return SafeArea(
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
        Row(children: [
          BackButton(onPressed: () => Navigator.pop(context)),
          Hud(it.code),
          const Spacer(),
          IconButton(
            tooltip: 'ویرایش',
            icon: const Icon(Icons.edit_outlined, color: V.silver),
            onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ItemEditorPage(item: it))),
          ),
          IconButton(
            tooltip: 'حذف',
            icon: const Icon(Icons.delete_outline, color: V.danger),
            onPressed: () async {
              final ok = await confirmDialog(context, 'انتقال به سطل بازیافت؟', 'تا ۳۰ روز می‌توانید بازگردانید.', ok: 'حذف', danger: true);
              if (ok) {
                await Db.i.trashItem(it.id);
                if (context.mounted) Navigator.pop(context);
              }
            },
          ),
        ]),
        const SizedBox(height: 6),
        Text(it.title.isEmpty ? it.origName : it.title,
            style: const TextStyle(color: V.text, fontSize: 20, fontWeight: FontWeight.w800, height: 1.4)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [ConfChip(it.conf), RelChip(it.rel)]),
        const SizedBox(height: 14),
        _media(context),
        const SizedBox(height: 14),
        if (it.hasFile)
          Wrap(spacing: 10, runSpacing: 10, children: [
            if (it.kind == 'image' || it.kind == 'video')
              VButton(label: 'ذخیره در گالری', icon: Icons.download_rounded, onTap: () => saveToGallery(context, it)),
            VButton(label: 'باز کردن', icon: Icons.open_in_new, filled: false, onTap: () => openItemFile(context, it)),
            VButton(label: 'اشتراک', icon: Icons.ios_share, filled: false, onTap: () => shareItem(context, it)),
          ]),
        if (it.lat != null && it.kind != 'location')
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: VButton(label: 'مکان ثبت‌شده روی نقشه', icon: Icons.place_outlined, filled: false, onTap: () => openMap(context, it.lat!, it.lng!, it.title)),
          ),
        if (it.kind == 'location' && it.lat != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: VButton(label: 'باز کردن در نقشه', icon: Icons.map_outlined, onTap: () => openMap(context, it.lat!, it.lng!, it.title)),
          ),
        const SectionTitle('مشخصات', hud: 'META'),
        VexCard(
          child: Column(children: [
            _row(
              'اشخاص',
              persons.isEmpty
                  ? const Text('—', style: TextStyle(color: V.textDim))
                  : Wrap(spacing: 8, runSpacing: 8, children: [
                      for (final x in persons)
                        InkWell(
                          onTap: () => openPerson(context, x.id),
                          child: Container(
                            padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                            decoration: BoxDecoration(border: Border.all(color: V.stroke), color: V.bg2),
                            child: Text(x.name, style: const TextStyle(color: V.silver, fontSize: 12)),
                          ),
                        ),
                    ]),
            ),
            _row('موضوع', Text(it.subject.isEmpty ? '—' : it.subject, style: const TextStyle(color: V.text))),
            _row(
              'هشتگ',
              it.tagList.isEmpty
                  ? const Text('—', style: TextStyle(color: V.textDim))
                  : Wrap(spacing: 6, runSpacing: 6, children: [
                      for (final t in it.tagList)
                        TagChip(t, onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => SearchPage(initial: t, standalone: true)))),
                    ]),
            ),
            _row('تاریخ', Text(jalaliLabel(it.dateTime), style: const TextStyle(color: V.text))),
            if (it.hasFile) _row('حجم', Text(fmtSize(it.size), style: const TextStyle(color: V.text))),
            if (it.hash.isNotEmpty)
              _row('اثر انگشت', Directionality(textDirection: TextDirection.ltr, child: Text(it.hash.substring(0, 16), style: V.mono(size: 10, color: V.textDim)))),
          ]),
        ),
        if (it.details.isNotEmpty) ...[
          const SectionTitle('جزئیات', hud: 'DETAILS'),
          VexCard(child: SizedBox(width: double.infinity, child: HiddenMedia(sigma: 6, hint: false, child: Text(it.details, style: const TextStyle(color: V.text, height: 1.8))))),
        ],
      ]),
    );
  }
}

class FullImagePage extends StatelessWidget {
  const FullImagePage({super.key, required this.item});
  final Item item;
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text('نگه‌دارید تا نمایش داده شود', style: V.mono(size: 10)),
          actions: [
            IconButton(icon: const Icon(Icons.download_rounded), onPressed: () => saveToGallery(context, item)),
          ],
        ),
        body: Center(
          child: InteractiveViewer(
            maxScale: 6,
            child: HiddenMedia(
              child: Image.file(File(Vault.path(item.file!)), fit: BoxFit.contain, cacheWidth: 2400),
            ),
          ),
        ),
      );
}

// ───────────────────────── انتخاب شخص ─────────────────────────

Future<Set<int>?> pickPersons(BuildContext context, Set<int> selected) => showModalBottomSheet<Set<int>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: V.card,
      builder: (_) => _PersonPicker(selected: selected),
    );

class _PersonPicker extends StatefulWidget {
  const _PersonPicker({required this.selected});
  final Set<int> selected;
  @override
  State<_PersonPicker> createState() => _PersonPickerState();
}

class _PersonPickerState extends State<_PersonPicker> {
  late final Set<int> _sel = Set<int>.of(widget.selected);
  final TextEditingController _q = TextEditingController();
  final TextEditingController _new = TextEditingController();
  List<Person> _all = <Person>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await Db.i.persons();
    if (mounted) setState(() => _all = l);
  }

  @override
  void dispose() {
    _q.dispose();
    _new.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = normFa(_q.text.trim());
    final list = _all.where((e) => q.isEmpty || normFa('${e.name} ${e.alias}').contains(q)).toList();
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * .8,
        child: Column(children: [
          const SizedBox(height: 14),
          const Text('انتخاب اشخاص', style: TextStyle(color: V.text, fontSize: 16, fontWeight: FontWeight.w700)),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: VField(controller: _q, label: 'جستجو در اشخاص', onChanged: (_) => setState(() {})),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Expanded(child: VField(controller: _new, label: 'شخص جدید (فقط نام)')),
              const SizedBox(width: 8),
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: VButton(
                  label: 'افزودن',
                  icon: Icons.add,
                  onTap: () async {
                    final n = _new.text.trim();
                    if (n.isEmpty) return;
                    final id = await Db.i.savePerson(Person(name: n));
                    _new.clear();
                    _sel.add(id);
                    await _load();
                  },
                ),
              ),
            ]),
          ),
          Expanded(
            child: list.isEmpty
                ? const EmptyState(icon: Icons.person_search_outlined, text: 'شخصی پیدا نشد.')
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final x = list[i];
                      final on = _sel.contains(x.id);
                      return ListTile(
                        leading: PersonAvatar(person: x, size: 42),
                        title: Text(x.name, style: const TextStyle(color: V.text)),
                        subtitle: x.alias.isEmpty ? null : Text(x.alias, style: const TextStyle(color: V.textDim)),
                        trailing: Icon(on ? Icons.check_box : Icons.check_box_outline_blank, color: on ? V.cyan : V.silverDim),
                        onTap: () => setState(() => on ? _sel.remove(x.id) : _sel.add(x.id)),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: VButton(label: 'تأیید (${faDigits(_sel.length)})', icon: Icons.check, expand: true, onTap: () => Navigator.pop(context, _sel)),
          ),
        ]),
      ),
    );
  }
}

// ───────────────────────── ثبت / ویرایش ─────────────────────────

class PickedFile {
  PickedFile(this.path, this.name, this.size);
  final String path;
  final String name;
  final int size;
}

/// انتخاب فایل از حافظه (هر قالبی)
Future<List<PickedFile>> pickFilesFromStorage() async {
  final r = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.any);
  if (r == null) return <PickedFile>[];
  return r.files.where((f) => f.path != null).map((f) => PickedFile(f.path!, f.name, f.size)).toList();
}

Future<List<PickedFile>> pickFromCamera() async {
  final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 95);
  if (x == null) return <PickedFile>[];
  final len = await File(x.path).length();
  return <PickedFile>[PickedFile(x.path, p.basename(x.path), len)];
}

class ItemEditorPage extends StatefulWidget {
  const ItemEditorPage({super.key, this.item, this.files = const <PickedFile>[], this.kind, this.personId});
  final Item? item;
  final List<PickedFile> files;
  final String? kind; // note | location | null
  final int? personId;
  @override
  State<ItemEditorPage> createState() => _ItemEditorPageState();
}

class _ItemEditorPageState extends State<ItemEditorPage> {
  final TextEditingController _title = TextEditingController();
  final TextEditingController _subject = TextEditingController();
  final TextEditingController _tags = TextEditingController();
  final TextEditingController _details = TextEditingController();
  final TextEditingController _body = TextEditingController();
  final TextEditingController _coord = TextEditingController();
  int _conf = 0;
  String _rel = 'D';
  DateTime _date = DateTime.now();
  bool _dateTouched = false;
  bool _busy = false;
  String _progress = '';
  final Set<int> _pids = <int>{};
  List<PickedFile> _files = <PickedFile>[];
  String _kind = 'file';
  double? _exLat;
  double? _exLng;
  List<String> _subjectSugg = <String>[];
  List<String> _tagSugg = <String>[];
  Map<int, Person> _pmap = <int, Person>{};

  bool get _editing => widget.item != null;

  @override
  void initState() {
    super.initState();
    final it = widget.item;
    if (it != null) {
      _kind = it.kind;
      _title.text = it.title;
      _subject.text = it.subject;
      _tags.text = it.tags;
      _details.text = it.details;
      _body.text = it.body;
      _conf = it.conf;
      _rel = it.rel;
      _date = it.dateTime;
      _dateTouched = true;
      _pids.addAll(it.personIds);
      if (it.kind == 'location' && it.lat != null) _coord.text = '${it.lat}, ${it.lng}';
    } else {
      _kind = widget.kind ?? 'file';
      _files = List<PickedFile>.of(widget.files);
      if (widget.personId != null) _pids.add(widget.personId!);
      _prepFiles();
    }
    _loadSuggestions();
  }

  Future<void> _loadSuggestions() async {
    final s = await Db.i.all();
    final sc = <String, int>{};
    final tc = <String, int>{};
    for (final it in s.items) {
      if (it.subject.isNotEmpty) sc[it.subject] = (sc[it.subject] ?? 0) + 1;
      for (final t in it.tagList) {
        tc[t] = (tc[t] ?? 0) + 1;
      }
    }
    List<String> top(Map<String, int> m) {
      final k = m.keys.toList()..sort((a, b) => m[b]!.compareTo(m[a]!));
      return k.take(10).toList();
    }

    if (!mounted) return;
    setState(() {
      _subjectSugg = top(sc);
      _tagSugg = top(tc);
      _pmap = s.pmap;
    });
  }

  Future<void> _prepFiles() async {
    if (_files.length != 1) return;
    final f = _files.first;
    try {
      _date = File(f.path).lastModifiedSync();
    } catch (_) {}
    if (Vault.kindOf(f.name) == 'image') {
      final ex = await Vault.exif(f.path);
      if (!mounted) return;
      setState(() {
        if (ex.date != null && !_dateTouched) _date = ex.date!;
        _exLat = ex.lat;
        _exLng = ex.lng;
      });
    } else {
      if (mounted) setState(() {});
    }
  }

  @override
  void dispose() {
    for (final c in <TextEditingController>[_title, _subject, _tags, _details, _body, _coord]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _addFiles(Future<List<PickedFile>> Function() src) async {
    final l = await src();
    if (l.isEmpty) return;
    setState(() {
      _files.addAll(l);
      if (_kind != 'file') _kind = 'file';
    });
    _prepFiles();
  }

  Future<void> _save() async {
    if (_busy) return;
    final tags = parseTags(_tags.text).join(' ');
    final base = Item(
      title: _title.text.trim(),
      kind: _kind,
      subject: _subject.text.trim(),
      tags: tags,
      details: _details.text.trim(),
      conf: _conf,
      rel: _rel,
      date: _date.millisecondsSinceEpoch,
      personIds: _pids.toList(),
    );
    setState(() => _busy = true);
    try {
      if (_editing) {
        final it = widget.item!;
        it.title = base.title;
        it.subject = base.subject;
        it.tags = base.tags;
        it.details = base.details;
        it.conf = _conf;
        it.rel = _rel;
        it.date = _date.millisecondsSinceEpoch;
        it.personIds = _pids.toList();
        if (it.kind == 'note') it.body = _body.text;
        if (it.kind == 'location') {
          final c = parseLatLng(_coord.text);
          if (c == null) {
            _fail('مختصات معتبر نیست. نمونه: ۳۵٫۶۸۹۲، ۵۱٫۳۸۹۰');
            return;
          }
          it.lat = c[0];
          it.lng = c[1];
        }
        await Db.i.saveItem(it);
        if (mounted) Navigator.pop(context, true);
        return;
      }

      if (_kind == 'note') {
        if (_body.text.trim().isEmpty && base.title.isEmpty) {
          _fail('متن یادداشت را بنویسید.');
          return;
        }
        base.body = _body.text;
        if (base.title.isEmpty) {
          final t = _body.text.trim().replaceAll('\n', ' ');
          base.title = t.length > 40 ? '${t.substring(0, 40)}…' : t;
        }
        await Db.i.saveItem(base);
      } else if (_kind == 'location') {
        final c = parseLatLng(_coord.text);
        if (c == null) {
          _fail('مختصات معتبر نیست. نمونه: ۳۵٫۶۸۹۲، ۵۱٫۳۸۹۰');
          return;
        }
        if (base.title.isEmpty) {
          _fail('برای مکان یک عنوان بنویسید.');
          return;
        }
        base.lat = c[0];
        base.lng = c[1];
        await Db.i.saveItem(base);
      } else {
        if (_files.isEmpty) {
          _fail('یک فایل انتخاب کنید.');
          return;
        }
        // بررسی تکراری‌ها با هش
        final hashes = <String>[];
        final dups = <int>{};
        for (var i = 0; i < _files.length; i++) {
          setState(() => _progress = 'بررسی ${faDigits(i + 1)} از ${faDigits(_files.length)}…');
          final h = await Vault.hashOf(_files[i].path);
          hashes.add(h);
          if (await Db.i.itemByHash(h) != null) dups.add(i);
        }
        var skipDups = false;
        if (dups.isNotEmpty) {
          if (!mounted) return;
          final keep = await confirmDialog(
            context,
            'فایل تکراری',
            '${faDigits(dups.length)} فایل قبلاً در آرشیو ثبت شده است. همچنان ثبت شوند؟\n(«انصراف» یعنی تکراری‌ها رد شوند)',
            ok: 'ثبت همه',
          );
          skipDups = !keep;
        }
        var saved = 0;
        for (var i = 0; i < _files.length; i++) {
          if (skipDups && dups.contains(i)) continue;
          setState(() => _progress = 'ذخیره ${faDigits(i + 1)} از ${faDigits(_files.length)}…');
          final f = _files[i];
          final kind = Vault.kindOf(f.name);
          final stored = await Vault.store(f.path, f.name);
          final it = Item(
            title: _files.length == 1
                ? (base.title.isEmpty ? p.basenameWithoutExtension(f.name) : base.title)
                : (base.title.isEmpty ? p.basenameWithoutExtension(f.name) : '${base.title} ${faDigits(i + 1)}'),
            kind: kind,
            file: stored,
            origName: f.name,
            size: await File(Vault.path(stored)).length(),
            hash: hashes[i],
            subject: base.subject,
            tags: base.tags,
            details: base.details,
            conf: _conf,
            rel: _rel,
            personIds: _pids.toList(),
          );
          DateTime d = _date;
          if (!_dateTouched || _files.length > 1) {
            try {
              d = File(f.path).lastModifiedSync();
            } catch (_) {}
          }
          if (kind == 'image') {
            final ex = (_files.length == 1 && (_exLat != null || _exLng != null)) ? null : await Vault.exif(f.path);
            if (_files.length == 1) {
              it.lat = _exLat;
              it.lng = _exLng;
              if (_dateTouched) d = _date;
            } else if (ex != null) {
              if (ex.date != null && !_dateTouched) d = ex.date!;
              it.lat = ex.lat;
              it.lng = ex.lng;
            }
          }
          if (_dateTouched) d = _date;
          it.date = d.millisecondsSinceEpoch;
          await Db.i.saveItem(it);
          saved++;
        }
        if (mounted) toast(context, '${faDigits(saved)} مورد ثبت شد.');
      }
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _fail('ثبت انجام نشد.');
    }
  }

  void _fail(String m) {
    if (!mounted) return;
    setState(() {
      _busy = false;
      _progress = '';
    });
    toast(context, m);
  }

  @override
  Widget build(BuildContext context) {
    final isNote = _kind == 'note';
    final isLoc = _kind == 'location';
    final title = _editing ? 'ویرایش مورد' : (isNote ? 'یادداشت جدید' : isLoc ? 'مکان جدید' : 'ثبت فایل');
    return Scaffold(
      appBar: AppBar(
        backgroundColor: V.bg,
        title: Text(title, style: const TextStyle(fontSize: 17)),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: VButton(label: 'ثبت', icon: Icons.check, onTap: _busy ? null : _save),
          ),
        ],
      ),
      body: Stack(children: [
        ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 40), children: [
          if (!_editing && !isNote && !isLoc) ...[
            VexCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Icon(Icons.attach_file, color: V.cyan, size: 20),
                  const SizedBox(width: 8),
                  Text(_files.isEmpty ? 'هنوز فایلی انتخاب نشده' : '${faDigits(_files.length)} فایل انتخاب شده',
                      style: const TextStyle(color: V.text, fontWeight: FontWeight.w600)),
                ]),
                if (_files.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  for (var i = 0; i < _files.length && i < 5; i++)
                    Padding(
                      padding: const EdgeInsets.only(top: 3),
                      child: Row(children: [
                        Icon(kindIcon(Vault.kindOf(_files[i].name)), size: 14, color: V.silverDim),
                        const SizedBox(width: 6),
                        Expanded(child: Text(_files[i].name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.textDim, fontSize: 12))),
                        Text(fmtSize(_files[i].size), style: const TextStyle(color: V.silverDim, fontSize: 11)),
                      ]),
                    ),
                  if (_files.length > 5)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text('و ${faDigits(_files.length - 5)} مورد دیگر…', style: const TextStyle(color: V.silverDim, fontSize: 12)),
                    ),
                ],
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  VButton(label: 'از حافظه', icon: Icons.folder_open, filled: false, onTap: () => _addFiles(pickFilesFromStorage)),
                  VButton(label: 'دوربین', icon: Icons.photo_camera_outlined, filled: false, onTap: () => _addFiles(pickFromCamera)),
                  if (_files.isNotEmpty) VButton(label: 'پاک‌کردن', icon: Icons.clear, filled: false, danger: true, onTap: () => setState(() => _files.clear())),
                ]),
              ]),
            ),
            const SizedBox(height: 14),
          ],
          VField(
              controller: _title,
              label: _files.length > 1 ? 'پیشوند عنوان (اختیاری)' : 'عنوان',
              hint: _files.length == 1 ? 'اگر خالی باشد نام فایل' : null),
          if (isNote) VField(controller: _body, label: 'متن یادداشت', maxLines: 12),
          if (isLoc || (_editing && _kind == 'location')) ...[
            VField(controller: _coord, label: 'مختصات (عرض، طول)', hint: '35.6892, 51.3890', ltr: true, keyboard: TextInputType.text),
          ],
          const SectionTitle('اشخاص مرتبط', hud: 'PERSONS'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final id in _pids)
              Chip(
                label: Text(_pmap[id]?.name ?? '…', style: const TextStyle(color: V.text, fontSize: 12)),
                backgroundColor: V.cardHi,
                side: const BorderSide(color: V.stroke),
                onDeleted: () => setState(() => _pids.remove(id)),
                deleteIconColor: V.silverDim,
              ),
            VButton(
              label: 'انتخاب',
              icon: Icons.person_add_alt,
              filled: false,
              onTap: () async {
                final r = await pickPersons(context, _pids);
                if (r != null) {
                  await _loadSuggestions();
                  setState(() {
                    _pids
                      ..clear()
                      ..addAll(r);
                  });
                }
              },
            ),
          ]),
          const SizedBox(height: 14),
          VField(controller: _subject, label: 'موضوع'),
          if (_subjectSugg.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Wrap(spacing: 6, runSpacing: 6, children: [
                for (final s in _subjectSugg) TagChip(s, onTap: () => setState(() => _subject.text = s)),
              ]),
            ),
          VField(controller: _tags, label: 'هشتگ‌ها', hint: '#راهنما #مورد'),
          if (_tagSugg.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Wrap(spacing: 6, runSpacing: 6, children: [
                for (final t in _tagSugg)
                  TagChip(t, onTap: () {
                    final cur = parseTags(_tags.text);
                    if (!cur.contains(t)) cur.add(t);
                    setState(() => _tags.text = cur.join(' '));
                  }),
              ]),
            ),
          VField(controller: _details, label: 'جزئیات', maxLines: 8),
          const SectionTitle('سطح‌بندی', hud: 'CLASSIFICATION'),
          const Padding(padding: EdgeInsets.only(bottom: 6), child: Text('محرمانگی', style: TextStyle(color: V.textDim, fontSize: 12))),
          ConfSelector(value: _conf, onChanged: (v) => setState(() => _conf = v)),
          const Padding(padding: EdgeInsets.only(top: 14, bottom: 6), child: Text('اعتبار منبع', style: TextStyle(color: V.textDim, fontSize: 12))),
          RelSelector(value: _rel, onChanged: (v) => setState(() => _rel = v)),
          const SectionTitle('تاریخ', hud: 'DATE'),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: VButton(
              label: jalaliLabel(_date),
              icon: Icons.event,
              filled: false,
              onTap: () async {
                final d = await pickJalali(context, _date);
                if (d != null) setState(() {
                      _date = d;
                      _dateTouched = true;
                    });
              },
            ),
          ),
          if (_exLat != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text('موقعیت مکانی از متادیتای عکس خوانده شد و همراه آن ثبت می‌شود.', style: const TextStyle(color: V.ok, fontSize: 12)),
            ),
        ]),
        if (_busy)
          Positioned.fill(
            child: Container(
              color: const Color(0xCC04070C),
              alignment: Alignment.center,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const CircularProgressIndicator(color: V.cyan, strokeWidth: 2),
                const SizedBox(height: 14),
                Text(_progress.isEmpty ? 'در حال ذخیره…' : _progress, style: const TextStyle(color: V.text)),
              ]),
            ),
          ),
      ]),
    );
  }
}
