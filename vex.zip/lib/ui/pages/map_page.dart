import 'dart:convert';
import 'dart:io';
import 'dart:math' show Point;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:maplibre_gl/maplibre_gl.dart';
import 'package:mbtiles/mbtiles.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/db.dart';
import '../widgets.dart';

/// مرکز پیش‌فرض نقشه: سرپل ذهاب
const LatLng _kDefaultCenter = LatLng(34.4569, 45.8614);

class MapPage extends StatefulWidget {
  const MapPage({super.key});
  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  MaplibreMapController? _map;
  List<Place> _places = <Place>[];
  List<RoutePath> _routes = <RoutePath>[];

  // سرور محلی نقشه
  MbTiles? _mbtiles;
  HttpServer? _server;
  String? _styleJson;
  String? _mapError;

  // حالت رسم مسیر
  bool _drawing = false;
  final List<LatLng> _draft = <LatLng>[];
  Line? _draftLine;
  final List<Circle> _draftDots = <Circle>[];
  final List<Circle> _placeMarkers = <Circle>[];
  final List<Line> _routeLines = <Line>[];

  @override
  void initState() {
    super.initState();
    _load();
    _initOfflineMap();
    Db.i.tick.addListener(_load);
  }

  @override
  void dispose() {
    Db.i.tick.removeListener(_load);
    _server?.close(force: true);
    _mbtiles?.close();
    super.dispose();
  }

  Future<void> _load() async {
    final pl = await Db.i.places();
    final rt = await Db.i.routes();
    if (mounted) {
      setState(() { _places = pl; _routes = rt; });
      await _renderStaticLayers();
    }
  }

  Future<void> _initOfflineMap() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final mbPath = '${dir.path}/sarpol.mbtiles';
      final f = File(mbPath);
      if (!await f.exists() || await f.length() == 0) {
        final bytes = await rootBundle.load('assets/map/sarpol.mbtiles');
        await f.writeAsBytes(bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes));
      }
      _mbtiles = MbTiles(path: mbPath, gzip: true);

      _server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      _server!.listen(_handleTileRequest);
      final port = _server!.port;

      final style = _buildStyle('http://127.0.0.1:$port/tiles/{z}/{x}/{y}.pbf');
      if (mounted) setState(() => _styleJson = jsonEncode(style));
    } catch (e) {
      if (mounted) setState(() => _mapError = 'نقشه‌ی آفلاین در دسترس نیست');
    }
  }

  void _handleTileRequest(HttpRequest req) async {
    try {
      final seg = req.uri.pathSegments; // tiles / z / x / y.pbf
      if (seg.length == 4 && seg[0] == 'tiles') {
        final z = int.parse(seg[1]);
        final x = int.parse(seg[2]);
        final y = int.parse(seg[3].split('.').first);
        final bytes = _mbtiles?.getTile(z: z, x: x, y: y);
        if (bytes == null) {
          req.response.statusCode = 404;
          await req.response.close();
          return;
        }
        req.response.headers.set('Content-Type', 'application/x-protobuf');
        req.response.headers.set('Content-Encoding', 'gzip');
        req.response.headers.set('Access-Control-Allow-Origin', '*');
        req.response.add(bytes);
        await req.response.close();
      } else {
        req.response.statusCode = 404;
        await req.response.close();
      }
    } catch (_) {
      req.response.statusCode = 500;
      await req.response.close();
    }
  }

  /// سبک نقشه (مطابق مشخصه‌ی MapLibre)، شامل ساختمان‌های سه‌بعدی (fill-extrusion)
  Map<String, Object?> _buildStyle(String tilesUrl) => <String, Object?>{
        'version': 8,
        'sources': {
          'openmaptiles': {
            'type': 'vector',
            'tiles': [tilesUrl],
            'minzoom': 0,
            'maxzoom': 14,
          },
        },
        'layers': [
          {'id': 'background', 'type': 'background', 'paint': {'background-color': '#070C14'}},
          _fillLayer('landcover-wood', 'landcover', ['==', ['get', 'class'], 'wood'], '#0E1A12', 0.8),
          _fillLayer('landcover-grass', 'landcover', ['==', ['get', 'class'], 'grass'], '#101A13', 0.7),
          _fillLayer('landuse-residential', 'landuse', ['==', ['get', 'class'], 'residential'], '#0C131E', 0.6),
          _fillLayer('landuse-industrial', 'landuse',
              ['in', ['get', 'class'], ['literal', ['industrial', 'commercial']]], '#15131A', 0.6),
          _fillLayer('park', 'park', null, '#0F2318', 0.7),
          _fillLayer('water', 'water', null, '#0B2A45', 1.0),
          {
            'id': 'waterway',
            'type': 'line',
            'source': 'openmaptiles',
            'source-layer': 'waterway',
            'paint': {'line-color': '#0B2A45', 'line-width': 1.2},
          },
          // ساختمان‌ها، کم‌ارتفاع (قبل از رسیدن به زوم سه‌بعدی)
          {
            'id': 'building-flat',
            'type': 'fill',
            'source': 'openmaptiles',
            'source-layer': 'building',
            'minzoom': 13,
            'maxzoom': 15,
            'paint': {'fill-color': '#111B2A', 'fill-outline-color': '#1C2A3E', 'fill-opacity': 0.95},
          },
          // ساختمان‌های سه‌بعدی واقعی (ارتفاع از خودِ داده‌ی OSM، در صورت وجود)
          {
            'id': 'building-3d',
            'type': 'fill-extrusion',
            'source': 'openmaptiles',
            'source-layer': 'building',
            'minzoom': 15,
            'paint': {
              'fill-extrusion-color': '#15202F',
              'fill-extrusion-height': [
                'interpolate', ['linear'], ['zoom'],
                15, 0,
                16, ['coalesce', ['get', 'render_height'], 7],
              ],
              'fill-extrusion-base': ['coalesce', ['get', 'render_min_height'], 0],
              'fill-extrusion-opacity': 0.92,
            },
          },
          _roadLayer('road-path', ['==', ['get', 'class'], 'path'], '#4A5568', 0.6, dash: [2, 2]),
          _roadLayer('road-service', ['in', ['get', 'class'], ['literal', ['service', 'track']]], '#5A6478', 1),
          _roadLayer('road-minor', ['==', ['get', 'class'], 'minor'], '#8593A6', 1.4),
          _roadLayer('road-tertiary', ['==', ['get', 'class'], 'tertiary'], '#A6B4C8', 1.8),
          _roadLayer('road-secondary', ['in', ['get', 'class'], ['literal', ['secondary', 'primary']]], '#4AC8FF', 2.4),
          _roadLayer('road-trunk-motorway', ['in', ['get', 'class'], ['literal', ['trunk', 'motorway']]], '#2F7BFF', 3.2),
          _roadLayer('railway', ['==', ['get', 'class'], 'rail'], '#8E9BAE', 1, dash: [3, 2]),
          {
            'id': 'boundary-admin',
            'type': 'line',
            'source': 'openmaptiles',
            'source-layer': 'boundary',
            'filter': ['>=', ['get', 'admin_level'], 4],
            'paint': {'line-color': '#E3B341', 'line-width': 1, 'line-dasharray': [4, 3], 'line-opacity': 0.6},
          },
        ],
      };

  Map<String, Object?> _fillLayer(String id, String sourceLayer, List<Object?>? filter, String color, double opacity) {
    final m = <String, Object?>{
      'id': id,
      'type': 'fill',
      'source': 'openmaptiles',
      'source-layer': sourceLayer,
      'paint': {'fill-color': color, 'fill-opacity': opacity},
    };
    if (filter != null) m['filter'] = filter;
    return m;
  }

  Map<String, Object?> _roadLayer(String id, List<Object?> filter, String color, double width, {List<int>? dash}) {
    final paint = <String, Object?>{'line-color': color, 'line-width': width};
    if (dash != null) paint['line-dasharray'] = dash;
    return {
      'id': id,
      'type': 'line',
      'source': 'openmaptiles',
      'source-layer': 'transportation',
      'filter': filter,
      'paint': paint,
    };
  }

  Future<void> _renderStaticLayers() async {
    final m = _map;
    if (m == null) return;
    for (final c in _placeMarkers) {
      await m.removeCircle(c);
    }
    _placeMarkers.clear();
    for (final l in _routeLines) {
      await m.removeLine(l);
    }
    _routeLines.clear();

    for (final p in _places) {
      final c = await m.addCircle(CircleOptions(
        geometry: LatLng(p.lat, p.lng),
        circleColor: '#E3B341',
        circleRadius: 7,
        circleStrokeColor: '#E8EEF6',
        circleStrokeWidth: 1.4,
      ));
      _placeMarkers.add(c);
    }
    for (final r in _routes) {
      if (r.points.length < 2) continue;
      final l = await m.addLine(LineOptions(
        geometry: r.points.map((p) => LatLng(p[0], p[1])).toList(),
        lineColor: '#4AC8FF',
        lineWidth: 3,
      ));
      _routeLines.add(l);
    }
  }

  Future<void> _onMapClick(Point<double> point, LatLng coord) async {
    if (!_drawing) return;
    _draft.add(coord);
    final m = _map!;
    if (_draftLine == null) {
      _draftLine = await m.addLine(LineOptions(geometry: List.of(_draft), lineColor: '#2F7BFF', lineWidth: 4));
    } else {
      await m.updateLine(_draftLine!, LineOptions(geometry: List.of(_draft)));
    }
    final dot = await m.addCircle(CircleOptions(
      geometry: coord,
      circleColor: '#2F7BFF',
      circleRadius: 5,
      circleStrokeColor: '#E8EEF6',
      circleStrokeWidth: 1,
    ));
    _draftDots.add(dot);
    setState(() {});
  }

  Future<void> _undoPoint() async {
    if (_draft.isEmpty) return;
    final m = _map!;
    _draft.removeLast();
    final dot = _draftDots.removeLast();
    await m.removeCircle(dot);
    if (_draft.length < 2 && _draftLine != null) {
      await m.removeLine(_draftLine!);
      _draftLine = null;
    } else if (_draftLine != null) {
      await m.updateLine(_draftLine!, LineOptions(geometry: List.of(_draft)));
    }
    setState(() {});
  }

  Future<void> _cancelDraw() async {
    final m = _map;
    if (m != null) {
      for (final d in _draftDots) {
        await m.removeCircle(d);
      }
      if (_draftLine != null) await m.removeLine(_draftLine!);
    }
    setState(() {
      _drawing = false;
      _draft.clear();
      _draftDots.clear();
      _draftLine = null;
    });
  }

  Future<void> _finishDraw() async {
    if (_draft.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حداقل دو نقطه لازم است')));
      return;
    }
    final types = await Db.i.routeTypes();
    if (!mounted) return;
    final result = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: V.card,
      builder: (c) => _RouteSaveSheet(existingTypes: types),
    );
    if (result == null) return;
    final pts = _draft.map((e) => <double>[e.latitude, e.longitude]).toList();
    await Db.i.saveRoute(RoutePath(type: result['type'] ?? '', name: result['name'] ?? '', points: pts));
    await _cancelDraw();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: V.bg2,
          title: Text('نقشه', style: V.mono(size: 13, color: V.silver)),
        ),
        body: Stack(children: [
          Container(color: V.bg2),
          if (_styleJson == null && _mapError == null) const Center(child: CircularProgressIndicator(color: V.cyan)),
          if (_mapError != null) Center(child: Text(_mapError!, style: const TextStyle(color: V.textDim))),
          if (_styleJson != null)
            MaplibreMap(
              styleString: _styleJson!,
              initialCameraPosition: const CameraPosition(target: _kDefaultCenter, zoom: 15, tilt: 45),
              onMapCreated: (c) => _map = c,
              onStyleLoadedCallback: _renderStaticLayers,
              onMapClick: _onMapClick,
              myLocationEnabled: false,
              compassEnabled: true,
              rotateGesturesEnabled: true,
              tiltGesturesEnabled: true,
            ),
          const Positioned(left: 8, top: 8, child: _OsmAttribution()),
          Positioned(
            left: 12,
            right: 12,
            bottom: 16,
            child: _drawing
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(color: V.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: V.stroke)),
                    child: Row(children: [
                      Expanded(child: Text('نقاط: ${faDigits(_draft.length)} — روی نقشه بزنید', style: const TextStyle(color: V.textDim, fontSize: 12))),
                      IconButton(onPressed: _undoPoint, icon: const Icon(Icons.undo, color: V.silver)),
                      IconButton(onPressed: _cancelDraw, icon: const Icon(Icons.close, color: V.danger)),
                      FilledButton(onPressed: _finishDraw, style: FilledButton.styleFrom(backgroundColor: V.accent), child: const Text('ثبت مسیر')),
                    ]),
                  )
                : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    FloatingActionButton.extended(
                      backgroundColor: V.accent,
                      onPressed: () => setState(() => _drawing = true),
                      icon: const Icon(Icons.alt_route),
                      label: const Text('مسیر جدید'),
                    ),
                  ]),
          ),
        ]),
      );
}

class _OsmAttribution extends StatelessWidget {
  const _OsmAttribution();
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(color: V.card.withOpacity(0.8), borderRadius: BorderRadius.circular(6)),
        child: const Text('© OpenStreetMap contributors', style: TextStyle(color: V.textDim, fontSize: 10)),
      );
}

class _RouteSaveSheet extends StatefulWidget {
  const _RouteSaveSheet({required this.existingTypes});
  final List<String> existingTypes;
  @override
  State<_RouteSaveSheet> createState() => _RouteSaveSheetState();
}

class _RouteSaveSheetState extends State<_RouteSaveSheet> {
  String? _type;
  final TextEditingController _newType = TextEditingController();
  final TextEditingController _name = TextEditingController();
  bool _addingType = false;

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('ثبت مسیر', style: V.mono(size: 12, color: V.silver)),
            const SizedBox(height: 14),
            Text('نوع', style: TextStyle(color: V.textDim, fontSize: 12)),
            const SizedBox(height: 6),
            if (!_addingType)
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final t in widget.existingTypes)
                  ChoiceChip(
                    label: Text(t),
                    selected: _type == t,
                    onSelected: (_) => setState(() => _type = t),
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add, size: 16, color: V.cyan),
                  label: const Text('نوع جدید'),
                  onPressed: () => setState(() => _addingType = true),
                ),
              ])
            else
              TextField(
                controller: _newType,
                autofocus: true,
                style: const TextStyle(color: V.text),
                decoration: const InputDecoration(hintText: 'مثلا: موتور، ماشین، پهباد، گله'),
                onSubmitted: (v) => setState(() { _type = v.trim(); _addingType = false; }),
              ),
            const SizedBox(height: 16),
            Text('نام', style: TextStyle(color: V.textDim, fontSize: 12)),
            const SizedBox(height: 6),
            TextField(
              controller: _name,
              style: const TextStyle(color: V.text),
              decoration: const InputDecoration(hintText: 'مثلا: موتور ۲، پهباد اصلی، ماشین پخش'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: V.accent),
                onPressed: () {
                  final type = (_type ?? _newType.text).trim();
                  final name = _name.text.trim();
                  if (type.isEmpty || name.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نوع و نام را وارد کنید')));
                    return;
                  }
                  Navigator.pop(context, <String, String>{'type': type, 'name': name});
                },
                child: const Text('ذخیره'),
              ),
            ),
          ]),
        ),
      );
}
