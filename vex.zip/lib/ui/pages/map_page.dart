import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as ll;

import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/db.dart';
import '../widgets.dart';

/// مرکز پیش‌فرض نقشه: سرپل ذهاب
const ll.LatLng _kDefaultCenter = ll.LatLng(34.4569, 45.8614);

class MapPage extends StatefulWidget {
  const MapPage({super.key});
  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final MapController _map = MapController();
  List<Place> _places = <Place>[];
  List<Route> _routes = <Route>[];

  // حالت رسم مسیر
  bool _drawing = false;
  final List<ll.LatLng> _draft = <ll.LatLng>[];

  @override
  void initState() {
    super.initState();
    _load();
    Db.i.tick.addListener(_load);
  }

  @override
  void dispose() {
    Db.i.tick.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final pl = await Db.i.places();
    final rt = await Db.i.routes();
    if (mounted) setState(() { _places = pl; _routes = rt; });
  }

  void _onTap(TapPosition _, ll.LatLng p) {
    if (!_drawing) return;
    setState(() => _draft.add(p));
  }

  void _undoPoint() {
    if (_draft.isEmpty) return;
    setState(() => _draft.removeLast());
  }

  void _cancelDraw() {
    setState(() { _drawing = false; _draft.clear(); });
  }

  Future<void> _finishDraw() async {
    if (_draft.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حداقل دو نقطه لازم است')));
      return;
    }
    final types = await Db.i.routeTypes();
    if (!mounted) return;
    final result = await showModalBottomSheet<Map<String, String>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: V.card,
      builder: (c) => _RouteSaveSheet(existingTypes: types),
    );
    if (result == null) return;
    final pts = _draft.map((e) => <double>[e.latitude, e.longitude]).toList();
    await Db.i.saveRoute(Route(type: result['type'] ?? '', name: result['name'] ?? '', points: pts));
    _cancelDraw();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: V.bg2,
          title: Text('نقشه', style: V.mono(size: 13, color: V.silver)),
        ),
        body: Stack(children: [
          FlutterMap(
            mapController: _map,
            options: MapOptions(
              initialCenter: _kDefaultCenter,
              initialZoom: 14,
              maxZoom: 19,
              onTap: _onTap,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.vex.vex_app',
                // TODO: جایگزینی با لایه‌ی کاشی‌های برداری آفلاین (mbtiles سرپل ذهاب)
                // به‌محض آماده شدن فایل در پایپ‌لاین GitHub Actions.
              ),
              // مسیرهای ثبت‌شده
              PolylineLayer(polylines: [
                for (final r in _routes)
                  if (r.points.length >= 2)
                    Polyline(
                      points: r.points.map((p) => ll.LatLng(p[0], p[1])).toList(),
                      strokeWidth: 3,
                      color: V.cyan,
                    ),
              ]),
              // مسیر در حال رسم
              if (_draft.length >= 2)
                PolylineLayer(polylines: [
                  Polyline(points: _draft, strokeWidth: 4, color: V.accent),
                ]),
              // نقاط مسیر در حال رسم
              if (_drawing)
                MarkerLayer(markers: [
                  for (final p in _draft)
                    Marker(
                      point: p,
                      width: 14,
                      height: 14,
                      child: Container(
                        decoration: BoxDecoration(color: V.accent, shape: BoxShape.circle, border: Border.all(color: V.text, width: 1.5)),
                      ),
                    ),
                ]),
              // مکان‌های ثابت اشخاص
              MarkerLayer(markers: [
                for (final p in _places)
                  Marker(
                    point: ll.LatLng(p.lat, p.lng),
                    width: 34,
                    height: 34,
                    child: GestureDetector(
                      onTap: () => _showPlaceInfo(p),
                      child: const Icon(Icons.location_on, color: V.warn, size: 32),
                    ),
                  ),
              ]),
            ],
          ),
          // نوار ابزار رسم مسیر
          Positioned(
            left: 12,
            right: 12,
            bottom: 16,
            child: _drawing
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(color: V.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: V.stroke)),
                    child: Row(children: [
                      Expanded(child: Text('نقاط: ${faDigits(_draft.length)} — روی نقشه بزنید', style: const TextStyle(color: V.textDim, fontSize: 12))),
                      IconButton(onPressed: _undoPoint, icon: const Icon(Icons.undo, color: V.silver)),
                      IconButton(onPressed: _cancelDraw, icon: const Icon(Icons.close, color: V.danger)),
                      FilledButton(onPressed: _finishDraw, style: FilledButton.styleFrom(backgroundColor: V.accent), child: const Text('ثبت مسیر')),
                    ]),
                  )
                : Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                    FloatingActionButton.extended(
                      backgroundColor: V.accent,
                      onPressed: () => setState(() => _drawing = true),
                      icon: const Icon(Icons.alt_route),
                      label: const Text('مسیر جدید'),
                    ),
                  ]),
          ),
        ]),
      );

  void _showPlaceInfo(Place p) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: V.card,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.title, style: const TextStyle(color: V.text, fontWeight: FontWeight.w700, fontSize: 15)),
            if (p.address.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(p.address, style: const TextStyle(color: V.textDim))),
            if (p.notes.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(p.notes, style: const TextStyle(color: V.silverDim))),
          ]),
        ),
      ),
    );
  }
}

class _RouteSaveSheet extends StatefulWidget {
  const _RouteSaveSheet({required this.existingTypes});
  final List<String> existingTypes;
  @override
  State<_RouteSaveSheet> createState() => _RouteSaveSheetState();
}

class _RouteSaveSheetState extends State<_RouteSaveSheet> {
  String? _type;
  final TextEditingController _newType = TextEditingController();
  final TextEditingController _name = TextEditingController();
  bool _addingType = false;

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('ثبت مسیر', style: V.mono(size: 12, color: V.silver)),
            const SizedBox(height: 14),
            Text('نوع', style: TextStyle(color: V.textDim, fontSize: 12)),
            const SizedBox(height: 6),
            if (!_addingType)
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final t in widget.existingTypes)
                  ChoiceChip(
                    label: Text(t),
                    selected: _type == t,
                    onSelected: (_) => setState(() => _type = t),
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add, size: 16, color: V.cyan),
                  label: const Text('نوع جدید'),
                  onPressed: () => setState(() => _addingType = true),
                ),
              ])
            else
              TextField(
                controller: _newType,
                autofocus: true,
                style: const TextStyle(color: V.text),
                decoration: const InputDecoration(hintText: 'مثلا: موتور، ماشین، پهباد، گله'),
                onSubmitted: (v) => setState(() { _type = v.trim(); _addingType = false; }),
              ),
            const SizedBox(height: 16),
            Text('نام', style: TextStyle(color: V.textDim, fontSize: 12)),
            const SizedBox(height: 6),
            TextField(
              controller: _name,
              style: const TextStyle(color: V.text),
              decoration: const InputDecoration(hintText: 'مثلا: موتور ۲، پهباد اصلی، ماشین پخش'),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: V.accent),
                onPressed: () {
                  final type = (_type ?? _newType.text).trim();
                  final name = _name.text.trim();
                  if (type.isEmpty || name.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نوع و نام را وارد کنید')));
                    return;
                  }
                  Navigator.pop(context, <String, String>{'type': type, 'name': name});
                },
                child: const Text('ذخیره'),
              ),
            ),
          ]),
        ),
      );
}
