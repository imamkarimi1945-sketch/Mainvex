import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/backup.dart';
import '../../data/db.dart';
import '../../data/security.dart';
import '../lock.dart';
import '../widgets.dart';
import 'item_pages.dart';
import 'person_pages.dart';

// ───────────────────────── تب سیستم ─────────────────────────

class SystemPage extends StatelessWidget {
  const SystemPage({super.key});

  Widget _tile(BuildContext context, IconData ic, String t, String sub, Widget page) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: VexCard(
          onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => page)),
          child: Row(children: [
            Icon(ic, color: V.cyan),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t, style: const TextStyle(color: V.text, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(sub, style: const TextStyle(color: V.textDim, fontSize: 12)),
              ]),
            ),
            const Icon(Icons.chevron_left, color: V.silverDim),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 30), children: [
          Row(children: [
            Image.asset('assets/logo/vex_logo.png', width: 44, height: 44),
            const SizedBox(width: 10),
            Text('SYSTEM', style: V.mono(size: 14, color: V.silver, spacing: 5)),
          ]),
          const SizedBox(height: 18),
          _tile(context, Icons.lock_outline, 'امنیت و قفل', 'رمز، اثر انگشت/الگو، قفل خودکار، پنهان‌سازی', const SecurityPage()),
          _tile(context, Icons.cloud_sync_outlined, 'بکاپ و بازیابی', 'فایل رمزگذاری‌شده‌ی .vex', const BackupPage()),
          _tile(context, Icons.hub_outlined, 'نقشه‌ی ارتباطات', 'اشخاص و پیوندهای مشترک', const GraphPage()),
          _tile(context, Icons.delete_sweep_outlined, 'سطل بازیافت', 'بازگردانی یا حذف کامل', const TrashPage()),
          const SizedBox(height: 14),
          Center(child: Text('VEX · v1.0 · OFFLINE', style: V.mono(size: 8, color: V.stroke))),
        ]),
      );
}

// ───────────────────────── امنیت ─────────────────────────

class SecurityPage extends StatelessWidget {
  const SecurityPage({super.key});

  Widget _mode(BuildContext context, String id, String title, String sub) {
    final s = Security.i;
    final on = s.mode == id;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: VexCard(
        borderColor: on ? V.accent : V.stroke,
        onTap: () => _setMode(context, id),
        child: Row(children: [
          Icon(on ? Icons.radio_button_checked : Icons.radio_button_off, color: on ? V.cyan : V.silverDim, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: V.text, fontWeight: FontWeight.w600)),
              Text(sub, style: const TextStyle(color: V.textDim, fontSize: 12)),
            ]),
          ),
        ]),
      ),
    );
  }

  Future<void> _setMode(BuildContext context, String id) async {
    final s = Security.i;
    if (s.mode == id) return;
    if (id == 'pin') {
      final pin = await askNewPin(context, s.pinLen);
      if (pin == null) return;
      await s.setPin(pin);
      await s.setMode('pin');
    } else if (id == 'device') {
      final ok = await s.deviceAuth('برای فعال‌سازی، هویت خود را تأیید کنید');
      if (!ok) {
        if (context.mounted) toast(context, 'قفل صفحه یا اثر انگشت گوشی فعال نیست یا تأیید نشد.');
        return;
      }
      await s.setMode('device');
    } else {
      if (s.mode == 'pin' && !await _verifyCurrent(context)) return;
      await s.setMode('off');
      await s.setBio(false);
    }
  }

  Future<bool> _verifyCurrent(BuildContext context) async {
    final s = Security.i;
    var ok = false;
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (c) => Scaffold(
          appBar: AppBar(backgroundColor: V.bg, title: const Text('تأیید رمز فعلی', style: TextStyle(fontSize: 17))),
          body: Center(
            child: PinPad(
              length: s.pinLen,
              onCompleted: (v) {
                if (s.checkPinOnly(v)) {
                  ok = true;
                  Navigator.pop(c);
                }
              },
            ),
          ),
        ),
      ),
    );
    return ok;
  }

  Widget _switch(String t, String sub, bool v, ValueChanged<bool> f) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: VexCard(
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t, style: const TextStyle(color: V.text, fontWeight: FontWeight.w600)),
                Text(sub, style: const TextStyle(color: V.textDim, fontSize: 12, height: 1.5)),
              ]),
            ),
            Switch(value: v, onChanged: f),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: V.bg, title: const Text('امنیت و قفل', style: TextStyle(fontSize: 17))),
        body: ListenableBuilder(
          listenable: Security.i,
          builder: (c, _) {
            final s = Security.i;
            return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30), children: [
              const SectionTitle('ورود به برنامه', hud: 'ACCESS'),
              _mode(context, 'off', 'خاموش', 'بدون قفل'),
              _mode(context, 'pin', 'رمز برنامه', 'رمز ۴ یا ۶ رقمی مخصوص Vex'),
              _mode(context, 'device', 'قفل گوشی', 'اثر انگشت، الگو یا رمز خودِ گوشی'),
              if (s.mode == 'pin') ...[
                _switch('اثر انگشت کنار رمز', 'ورود سریع با اثر انگشت/الگوی گوشی', s.bio, (v) async {
                  if (v && !await s.deviceAuth('تأیید برای فعال‌سازی')) return;
                  await s.setBio(v);
                }),
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    Expanded(
                      child: VButton(
                        label: 'تغییر رمز (۴ رقمی)',
                        filled: false,
                        onTap: () async {
                          final p = await askNewPin(context, 4);
                          if (p != null) await s.setPin(p);
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: VButton(
                        label: 'تغییر رمز (۶ رقمی)',
                        filled: false,
                        onTap: () async {
                          final p = await askNewPin(context, 6);
                          if (p != null) await s.setPin(p);
                        },
                      ),
                    ),
                  ]),
                ),
              ],
              if (s.mode != 'off') ...[
                const SectionTitle('قفل خودکار', hud: 'AUTO-LOCK'),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final e in const <MapEntry<int, String>>[
                    MapEntry<int, String>(0, 'فوری'),
                    MapEntry<int, String>(30, '۳۰ ثانیه'),
                    MapEntry<int, String>(120, '۲ دقیقه'),
                    MapEntry<int, String>(600, '۱۰ دقیقه'),
                  ])
                    InkWell(
                      onTap: () => s.setAutoLock(e.key),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                        decoration: BoxDecoration(
                          color: s.autoLockSec == e.key ? V.a(V.accent, .2) : V.card,
                          border: Border.all(color: s.autoLockSec == e.key ? V.accent : V.stroke),
                        ),
                        child: Text(e.value, style: TextStyle(color: s.autoLockSec == e.key ? V.text : V.textDim, fontSize: 13)),
                      ),
                    ),
                ]),
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('پس از رفتن به پس‌زمینه، بعد از این مدت قفل می‌شود. رمز اشتباه سه بار = تأخیر فزاینده.',
                      style: TextStyle(color: V.textDim, fontSize: 12, height: 1.6)),
                ),
              ],
              const SectionTitle('حریم خصوصی', hud: 'PRIVACY'),
              _switch('محو بودن فایل‌ها', 'تصویرها و متن‌ها پیش‌فرض تار هستند؛ انگشت را نگه دارید تا دیده شوند.', s.hideMedia, s.setHide),
              _switch('جلوگیری از اسکرین‌شات', 'ضبط/اسکرین‌شات و پیش‌نمایش برنامه‌های اخیر سیاه می‌شود.', s.secureFlag, s.setSecureFlag),
            ]);
          },
        ),
      );
}

// ───────────────────────── بکاپ ─────────────────────────

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  bool _busy = false;
  double _prog = 0;
  String _what = '';
  int _lastUi = 0;

  void _progress(double v) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastUi < 120 && v < 1) return;
    _lastUi = now;
    if (mounted) setState(() => _prog = v);
  }

  Future<String?> _askPassword({required bool confirm, required String title}) {
    final a = TextEditingController();
    final b = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: V.card,
        shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: V.stroke)),
        title: Text(title, style: const TextStyle(color: V.text, fontSize: 17)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          VField(controller: a, label: 'رمز', obscure: true),
          if (confirm) VField(controller: b, label: 'تکرار رمز', obscure: true),
          if (confirm)
            const Text('اگر این رمز را فراموش کنید، هیچ راهی برای بازیابی بکاپ نیست.', style: TextStyle(color: V.warn, fontSize: 12, height: 1.6)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('انصراف')),
          TextButton(
            onPressed: () {
              if (a.text.length < 6) {
                toast(c, 'رمز باید حداقل ۶ نویسه باشد.');
                return;
              }
              if (confirm && a.text != b.text) {
                toast(c, 'دو رمز یکسان نیست.');
                return;
              }
              Navigator.pop(c, a.text);
            },
            child: const Text('تأیید', style: TextStyle(color: V.cyan)),
          ),
        ],
      ),
    );
  }

  Future<void> _backup() async {
    final pw = await _askPassword(confirm: true, title: 'رمز بکاپ');
    if (pw == null) return;
    setState(() {
      _busy = true;
      _prog = 0;
      _what = 'در حال ساخت بکاپ رمزگذاری‌شده…';
    });
    try {
      final path = await createBackup(pw, _progress);
      if (!mounted) return;
      setState(() => _busy = false);
      toast(context, 'بکاپ آماده شد؛ محل ذخیره را انتخاب کنید.');
      await Share.shareXFiles(<XFile>[XFile(path)]);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        toast(context, 'ساخت بکاپ انجام نشد.');
      }
    }
  }

  Future<void> _restore() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    if (r == null || r.files.isEmpty || r.files.first.path == null) return;
    final path = r.files.first.path!;
    if (!mounted) return;
    final pw = await _askPassword(confirm: false, title: 'رمز بکاپ');
    if (pw == null || !mounted) return;
    final ok = await confirmDialog(context, 'جایگزینی کل اطلاعات', 'همه‌ی اطلاعات فعلی حذف و با محتوای بکاپ جایگزین می‌شود. ادامه می‌دهید؟', ok: 'بازیابی', danger: true);
    if (!ok) return;
    setState(() {
      _busy = true;
      _prog = 0;
      _what = 'در حال بازیابی…';
    });
    try {
      await restoreBackup(path, pw, _progress);
      if (mounted) {
        setState(() => _busy = false);
        toast(context, 'همه‌ی اطلاعات بازگردانده شد.');
      }
    } on BackupException catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        toast(context, e.message);
      }
    } catch (_) {
      if (mounted) {
        setState(() => _busy = false);
        toast(context, 'بازیابی انجام نشد.');
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: V.bg, title: const Text('بکاپ و بازیابی', style: TextStyle(fontSize: 17))),
        body: Stack(children: [
          ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30), children: [
            const SectionTitle('بکاپ', hud: 'EXPORT'),
            const Text(
              'همه‌ی اشخاص، فایل‌ها، مکان‌ها و جزئیات در یک فایل با پسوند .vex ذخیره می‌شود. این فایل با AES-256 رمزگذاری شده و فقط همین برنامه با رمزِ تعیین‌شده می‌تواند آن را باز کند.',
              style: TextStyle(color: V.textDim, height: 1.8, fontSize: 13),
            ),
            const SizedBox(height: 14),
            VButton(label: 'ساخت بکاپ', icon: Icons.upload_file, expand: true, onTap: _busy ? null : _backup),
            const SectionTitle('بازیابی', hud: 'IMPORT'),
            const Text('فایل .vex را انتخاب کنید و رمز را بزنید؛ کل اطلاعات یکجا برمی‌گردد. اطلاعات فعلی جایگزین می‌شود.',
                style: TextStyle(color: V.textDim, height: 1.8, fontSize: 13)),
            const SizedBox(height: 14),
            VButton(label: 'آپلود و بازیابی', icon: Icons.download_for_offline_outlined, filled: false, expand: true, onTap: _busy ? null : _restore),
          ]),
          if (_busy)
            Positioned.fill(
              child: Container(
                color: const Color(0xDD04070C),
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(_what, style: const TextStyle(color: V.text)),
                    const SizedBox(height: 16),
                    LinearProgressIndicator(value: _prog <= 0 ? null : _prog, color: V.cyan, backgroundColor: V.stroke),
                    const SizedBox(height: 8),
                    Text(faDigits('${(_prog * 100).round()}%'), style: V.mono(size: 10, color: V.silverDim)),
                  ]),
                ),
              ),
            ),
        ]),
      );
}

// ───────────────────────── سطل بازیافت ─────────────────────────

class TrashPage extends StatelessWidget {
  const TrashPage({super.key});

  Future<(List<Person>, List<Item>)> _load() async => (await Db.i.persons(trashed: true), await Db.i.items(trashed: true));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: V.bg,
          title: const Text('سطل بازیافت', style: TextStyle(fontSize: 17)),
          actions: [
            TextButton(
              onPressed: () async {
                final ok = await confirmDialog(context, 'خالی‌کردن سطل؟', 'همه‌ی موارد برای همیشه حذف می‌شوند.', ok: 'حذف کامل', danger: true);
                if (ok) await Db.i.emptyTrash();
              },
              child: const Text('خالی‌کردن', style: TextStyle(color: V.danger)),
            ),
          ],
        ),
        body: DbBuilder<(List<Person>, List<Item>)>(
          load: _load,
          builder: (c, d) {
            final ps = d.$1;
            final its = d.$2;
            if (ps.isEmpty && its.isEmpty) return const EmptyState(icon: Icons.delete_outline, text: 'سطل بازیافت خالی است.\nموارد حذف‌شده ۳۰ روز نگه داشته می‌شوند.');
            return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 30), children: [
              for (final x in ps)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: VexCard(
                    child: Row(children: [
                      PersonAvatar(person: x, size: 42),
                      const SizedBox(width: 12),
                      Expanded(child: Text(x.name, style: const TextStyle(color: V.text))),
                      IconButton(icon: const Icon(Icons.restore, color: V.cyan), onPressed: () => Db.i.restorePerson(x.id)),
                      IconButton(icon: const Icon(Icons.delete_forever_outlined, color: V.danger), onPressed: () => Db.i.purgePerson(x.id)),
                    ]),
                  ),
                ),
              for (final it in its)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: VexCard(
                    child: Row(children: [
                      Icon(kindIcon(it.kind), color: V.silverDim),
                      const SizedBox(width: 12),
                      Expanded(child: Text(it.title.isEmpty ? it.origName : it.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.text))),
                      IconButton(icon: const Icon(Icons.restore, color: V.cyan), onPressed: () => Db.i.restoreItem(it.id)),
                      IconButton(icon: const Icon(Icons.delete_forever_outlined, color: V.danger), onPressed: () => Db.i.purgeItem(it.id)),
                    ]),
                  ),
                ),
            ]);
          },
        ),
      );
}

// ───────────────────────── نقشه‌ی ارتباطات ─────────────────────────

class GraphPage extends StatelessWidget {
  const GraphPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: V.bg, title: const Text('نقشه‌ی ارتباطات', style: TextStyle(fontSize: 17))),
        body: DbBuilder<Snap>(load: Db.i.all, builder: (c, s) => _Graph(snap: s)),
      );
}

class _EdgePainter extends CustomPainter {
  _EdgePainter(this.edges, this.pos);
  final List<(int, int, int)> edges;
  final Map<int, Offset> pos;
  @override
  void paint(Canvas canvas, Size size) {
    for (final e in edges) {
      final a = pos[e.$1];
      final b = pos[e.$2];
      if (a == null || b == null) continue;
      final w = min(6.0, 1.0 + e.$3 * 0.8);
      canvas.drawLine(a, b, Paint()
        ..color = V.a(V.accent, .55)
        ..strokeWidth = w);
    }
  }

  @override
  bool shouldRepaint(covariant _EdgePainter o) => true;
}

class _Graph extends StatelessWidget {
  const _Graph({required this.snap});
  final Snap snap;

  @override
  Widget build(BuildContext context) {
    final w = <String, int>{};
    final deg = <int, int>{};
    for (final it in snap.items) {
      final ids = it.personIds.where(snap.pmap.containsKey).toList()..sort();
      for (var i = 0; i < ids.length; i++) {
        for (var j = i + 1; j < ids.length; j++) {
          final k = '${ids[i]}-${ids[j]}';
          w[k] = (w[k] ?? 0) + 1;
        }
      }
    }
    final edges = <(int, int, int)>[];
    w.forEach((k, v) {
      final p = k.split('-');
      final a = int.parse(p[0]);
      final b = int.parse(p[1]);
      edges.add((a, b, v));
      deg[a] = (deg[a] ?? 0) + v;
      deg[b] = (deg[b] ?? 0) + v;
    });
    if (edges.isEmpty) {
      return const EmptyState(icon: Icons.hub_outlined, text: 'هنوز ارتباطی نیست.\nوقتی یک فایل را به چند شخص وصل کنید، پیوند آن‌ها اینجا کشیده می‌شود.');
    }
    final nodes = snap.persons.where((e) => deg.containsKey(e.id)).toList()..sort((a, b) => (deg[b.id] ?? 0).compareTo(deg[a.id] ?? 0));
    final shown = nodes.take(40).toList();
    const canvas = 900.0;
    const c = canvas / 2;
    final pos = <int, Offset>{};
    final inner = shown.take(8).toList();
    final outer = shown.skip(8).toList();
    for (var i = 0; i < inner.length; i++) {
      final a = 2 * pi * i / max(1, inner.length);
      pos[inner[i].id] = Offset(c + 150 * cos(a), c + 150 * sin(a));
    }
    for (var i = 0; i < outer.length; i++) {
      final a = 2 * pi * i / max(1, outer.length) + 0.3;
      pos[outer[i].id] = Offset(c + 340 * cos(a), c + 340 * sin(a));
    }
    final es = edges.where((e) => pos.containsKey(e.$1) && pos.containsKey(e.$2)).toList();
    return InteractiveViewer(
      constrained: false,
      minScale: 0.3,
      maxScale: 3,
      boundaryMargin: const EdgeInsets.all(300),
      child: SizedBox(
        width: canvas,
        height: canvas,
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(painter: _EdgePainter(es, pos))),
          for (final x in shown)
            Positioned(
              left: pos[x.id]!.dx - 36,
              top: pos[x.id]!.dy - 36,
              width: 72,
              child: GestureDetector(
                onTap: () => openPerson(context, x.id),
                child: Column(children: [
                  PersonAvatar(person: x, size: 56, bracket: true),
                  const SizedBox(height: 4),
                  Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.text, fontSize: 11)),
                ]),
              ),
            ),
        ]),
      ),
    );
  }
}
