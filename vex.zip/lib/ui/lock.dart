import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../core/util.dart';
import '../data/security.dart';
import 'widgets.dart';

/// صفحه‌کلید عددی و نقطه‌ها
class PinPad extends StatefulWidget {
  const PinPad({super.key, required this.length, required this.onCompleted, this.error = false, this.enabled = true, this.extra});
  final int length;
  final ValueChanged<String> onCompleted;
  final bool error;
  final bool enabled;
  final Widget? extra; // دکمه‌ی گوشه (مثلاً اثر انگشت)

  @override
  State<PinPad> createState() => PinPadState();
}

class PinPadState extends State<PinPad> {
  String _v = '';

  void clear() => setState(() => _v = '');

  void _add(String d) {
    if (!widget.enabled || _v.length >= widget.length) return;
    HapticFeedback.selectionClick();
    setState(() => _v += d);
    if (_v.length == widget.length) widget.onCompleted(_v);
  }

  void _back() {
    if (_v.isEmpty) return;
    setState(() => _v = _v.substring(0, _v.length - 1));
  }

  Widget _key(String label, {VoidCallback? onTap, Widget? child}) => Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: onTap,
          child: SizedBox(
            height: 66,
            child: Center(child: child ?? Text(label, style: V.mono(size: 24, color: V.silver, spacing: 0))),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final c = widget.error ? V.danger : V.cyan;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (var i = 0; i < widget.length; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            margin: const EdgeInsets.symmetric(horizontal: 8),
            width: 14,
            height: 14,
            decoration: BoxDecoration(
              color: i < _v.length ? c : Colors.transparent,
              border: Border.all(color: i < _v.length ? c : V.silverDim, width: 1.5),
            ),
          ),
      ]),
      const SizedBox(height: 26),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Column(children: [
          for (final row in const <List<String>>[
            <String>['1', '2', '3'],
            <String>['4', '5', '6'],
            <String>['7', '8', '9'],
          ])
            Row(children: [for (final d in row) _key(d, onTap: () => _add(d))]),
          Row(children: [
            _key('', child: widget.extra, onTap: null),
            _key('0', onTap: () => _add('0')),
            _key('', onTap: _back, child: const Icon(Icons.backspace_outlined, color: V.silverDim, size: 22)),
          ]),
        ]),
      ),
    ]);
  }
}

/// پوشش قفل روی کل برنامه
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final GlobalKey<PinPadState> _pad = GlobalKey<PinPadState>();
  bool _err = false;
  Timer? _t;
  bool _authing = false;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final s = Security.i;
      if (s.mode == 'device' || (s.mode == 'pin' && s.bio)) _deviceAuth();
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _deviceAuth() async {
    if (_authing) return;
    _authing = true;
    final ok = await Security.i.deviceAuth('برای ورود به Vex هویت خود را تأیید کنید');
    _authing = false;
    if (ok) await Security.i.unlock();
  }

  Future<void> _onPin(String pin) async {
    final ok = await Security.i.tryPin(pin);
    if (!ok) {
      HapticFeedback.heavyImpact();
      setState(() => _err = true);
      await Future<void>.delayed(const Duration(milliseconds: 500));
      _pad.currentState?.clear();
      if (mounted) setState(() => _err = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = Security.i;
    final wait = (s.remainingLockMs / 1000).ceil();
    return Material(
      color: V.bg,
      child: SafeArea(
        child: Column(children: [
          const Spacer(flex: 2),
          Image.asset('assets/logo/vex_logo.png', width: 190, height: 190),
          const SizedBox(height: 6),
          Text('VEX', style: V.mono(size: 22, color: V.silver, spacing: 10)),
          const SizedBox(height: 8),
          Text(wait > 0 ? 'ورود موقتاً مسدود است' : 'دسترسی محدود', style: V.mono(size: 9, color: wait > 0 ? V.danger : V.silverDim)),
          const Spacer(),
          if (s.mode == 'pin') ...[
            if (wait > 0)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Text('${faDigits(wait)} ثانیه صبر کنید', style: const TextStyle(color: V.danger, fontSize: 16)),
              )
            else
              PinPad(
                key: _pad,
                length: s.pinLen,
                error: _err,
                onCompleted: _onPin,
                extra: s.bio ? IconButton(icon: const Icon(Icons.fingerprint, color: V.cyan, size: 32), onPressed: _deviceAuth) : null,
              ),
          ] else
            VButton(label: 'تأیید هویت', icon: Icons.fingerprint, onTap: _deviceAuth),
          const Spacer(flex: 2),
        ]),
      ),
    );
  }
}

/// دریافت دوبارهٔ رمز جدید
Future<String?> askNewPin(BuildContext context, int length) => Navigator.push<String>(
      context,
      MaterialPageRoute<String>(builder: (_) => _NewPinPage(length: length)),
    );

class _NewPinPage extends StatefulWidget {
  const _NewPinPage({required this.length});
  final int length;
  @override
  State<_NewPinPage> createState() => _NewPinPageState();
}

class _NewPinPageState extends State<_NewPinPage> {
  final GlobalKey<PinPadState> _pad = GlobalKey<PinPadState>();
  String? _first;
  bool _err = false;

  Future<void> _done(String v) async {
    if (_first == null) {
      setState(() => _first = v);
      _pad.currentState?.clear();
      return;
    }
    if (_first == v) {
      Navigator.pop(context, v);
    } else {
      setState(() {
        _err = true;
        _first = null;
      });
      await Future<void>.delayed(const Duration(milliseconds: 600));
      _pad.currentState?.clear();
      if (mounted) setState(() => _err = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(backgroundColor: V.bg, title: const Text('تعیین رمز', style: TextStyle(fontSize: 17))),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_err ? 'رمزها یکسان نبود؛ دوباره شروع کنید' : (_first == null ? 'رمز جدید را وارد کنید' : 'رمز را دوباره وارد کنید'),
                style: TextStyle(color: _err ? V.danger : V.text, fontSize: 16)),
            const SizedBox(height: 30),
            PinPad(key: _pad, length: widget.length, error: _err, onCompleted: _done),
          ]),
        ),
      );
}
