import 'package:flutter/material.dart';

/// پالت و استایل Vex — تیره، فلز نقره‌ای، آبی نئونی.
class V {
  V._();
  static const Color bg = Color(0xFF04070C);
  static const Color bg2 = Color(0xFF070C14);
  static const Color card = Color(0xFF0B121C);
  static const Color cardHi = Color(0xFF111B2A);
  static const Color stroke = Color(0xFF1C2A3E);
  static const Color accent = Color(0xFF2F7BFF);
  static const Color cyan = Color(0xFF4AC8FF);
  static const Color silver = Color(0xFFD3DBE6);
  static const Color silverDim = Color(0xFF8593A6);
  static const Color text = Color(0xFFE8EEF6);
  static const Color textDim = Color(0xFF8E9BAE);
  static const Color warn = Color(0xFFE3B341);
  static const Color danger = Color(0xFFE5534B);
  static const Color ok = Color(0xFF3FB68B);

  /// سطح محرمانگی (۰ تا ۳)
  static const List<Color> confColors = <Color>[
    Color(0xFF4AC8FF),
    Color(0xFFE3B341),
    Color(0xFFF08A3C),
    Color(0xFFE5534B),
  ];
  static const List<String> confNames = <String>['عادی', 'محدود', 'محرمانه', 'فوق‌سری'];

  /// سطح اعتبار منبع
  static const Map<String, String> relNames = <String, String>{
    'A': 'تأییدشده',
    'B': 'معتبر',
    'C': 'نامطمئن',
    'D': 'ارزیابی‌نشده',
  };
  static const Map<String, Color> relColors = <String, Color>{
    'A': Color(0xFF3FB68B),
    'B': Color(0xFF4AC8FF),
    'C': Color(0xFFE3B341),
    'D': Color(0xFF8593A6),
  };

  static Color a(Color c, double o) => c.withAlpha((o * 255).round().clamp(0, 255));

  static TextStyle mono({double size = 10, Color color = silverDim, double spacing = 1.8}) => TextStyle(
        fontFamily: 'Michroma',
        fontFamilyFallback: const <String>['Estedad', 'Vazirmatn'],
        fontSize: size,
        letterSpacing: spacing,
        color: color,
      );
}

ThemeData vexTheme() {
  const scheme = ColorScheme.dark(
    primary: V.accent,
    secondary: V.cyan,
    surface: V.card,
    onSurface: V.text,
    error: V.danger,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: V.bg,
    fontFamily: 'Estedad',
    fontFamilyFallback: const <String>['Vazirmatn'],
    canvasColor: V.bg2,
    splashFactory: InkRipple.splashFactory,
  );
}
