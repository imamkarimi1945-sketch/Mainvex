import 'package:shamsi_date/shamsi_date.dart';

const List<String> jalaliMonths = <String>[
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

const List<String> _faDigits = <String>['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

String faDigits(Object? v) {
  final s = (v ?? '').toString();
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    final d = int.tryParse(c);
    b.write(d != null ? _faDigits[d] : c);
  }
  return b.toString();
}

/// رقم فارسی/عربی → لاتین
String enDigits(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    if (r >= 0x06F0 && r <= 0x06F9) {
      b.write(r - 0x06F0);
    } else if (r >= 0x0660 && r <= 0x0669) {
      b.write(r - 0x0660);
    } else if (r == 0x066B) {
      b.write('.');
    } else if (r == 0x060C) {
      b.write(',');
    } else {
      b.writeCharCode(r);
    }
  }
  return b.toString();
}

/// یکدست‌سازی متن فارسی برای جستجو
String normFa(String s) {
  var t = enDigits(s.toLowerCase());
  t = t
      .replaceAll('ي', 'ی')
      .replaceAll('ك', 'ک')
      .replaceAll('ۀ', 'ه')
      .replaceAll('ة', 'ه')
      .replaceAll('أ', 'ا')
      .replaceAll('إ', 'ا')
      .replaceAll('\u200c', '')
      .replaceAll('\u0640', '');
  t = t.replaceAll(RegExp('[\u064B-\u065F]'), '');
  return t;
}

String two(int n) => n.toString().padLeft(2, '0');

String jalaliLabel(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return '${faDigits(j.day)} ${jalaliMonths[j.month - 1]} ${faDigits(j.year)}';
}

String jalaliShort(DateTime d) {
  final j = Jalali.fromDateTime(d);
  return faDigits('${j.year}/${two(j.month)}/${two(j.day)}');
}

String fmtSize(int bytes) {
  if (bytes < 1024) return '${faDigits(bytes)} B';
  final kb = bytes / 1024;
  if (kb < 1024) return '${faDigits(kb.toStringAsFixed(0))} KB';
  final mb = kb / 1024;
  if (mb < 1024) return '${faDigits(mb.toStringAsFixed(1))} MB';
  return '${faDigits((mb / 1024).toStringAsFixed(2))} GB';
}

/// «۳۵٫۶۸۹۲، ۵۱٫۳۸۹۰» یا لینک نقشه → [lat, lng]
List<double>? parseLatLng(String input) {
  final s = enDigits(input);
  final m = RegExp(r'(-?\d{1,3}(?:\.\d+)?)\s*[,\s;/]\s*(-?\d{1,3}(?:\.\d+)?)').firstMatch(s);
  if (m == null) return null;
  final lat = double.tryParse(m.group(1)!);
  final lng = double.tryParse(m.group(2)!);
  if (lat == null || lng == null) return null;
  if (lat.abs() > 90 || lng.abs() > 180) return null;
  return <double>[lat, lng];
}

/// «#الف، ب  #ج» → ['#الف', '#ب', '#ج']
List<String> parseTags(String input) {
  final out = <String>[];
  for (final raw in input.split(RegExp(r'[\s,،;]+'))) {
    var t = raw.trim();
    if (t.isEmpty) continue;
    t = t.replaceAll(RegExp(r'^#+'), '');
    if (t.isEmpty) continue;
    final tag = '#$t';
    if (!out.contains(tag)) out.add(tag);
  }
  return out;
}
